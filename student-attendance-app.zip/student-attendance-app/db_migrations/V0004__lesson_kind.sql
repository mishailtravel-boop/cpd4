ALTER TABLE t_p88797006_student_attendance_a.lessons ADD COLUMN kind TEXT NOT NULL DEFAULT '';
UPDATE t_p88797006_student_attendance_a.lessons SET room = '' WHERE room = 'ауд. —';
CREATE TABLE t_p88797006_student_attendance_a.posts (
  id SERIAL PRIMARY KEY,
  author_id TEXT NOT NULL,
  author_name TEXT NOT NULL,
  text TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  hidden BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE t_p88797006_student_attendance_a.post_reactions (
  post_id INTEGER NOT NULL,
  student_id TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  PRIMARY KEY (post_id, student_id)
);

CREATE TABLE t_p88797006_student_attendance_a.post_comments (
  id SERIAL PRIMARY KEY,
  post_id INTEGER NOT NULL,
  author_id TEXT NOT NULL,
  author_name TEXT NOT NULL,
  text TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  hidden BOOLEAN NOT NULL DEFAULT FALSE
);
CREATE INDEX post_comments_post_idx ON t_p88797006_student_attendance_a.post_comments (post_id, id);
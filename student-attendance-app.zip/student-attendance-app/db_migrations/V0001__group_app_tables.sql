CREATE TABLE t_p88797006_student_attendance_a.students (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'student',
  hours_adjust INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX students_name_lower_idx ON t_p88797006_student_attendance_a.students (LOWER(name));

CREATE TABLE t_p88797006_student_attendance_a.lessons (
  id TEXT PRIMARY KEY,
  parity TEXT NOT NULL,
  weekday TEXT NOT NULL,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  subject TEXT NOT NULL,
  room TEXT NOT NULL DEFAULT ''
);

CREATE TABLE t_p88797006_student_attendance_a.homework (
  subject TEXT PRIMARY KEY,
  text TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE t_p88797006_student_attendance_a.attendance (
  day TEXT NOT NULL,
  student_id TEXT NOT NULL,
  status TEXT NOT NULL,
  lesson_ids TEXT NOT NULL DEFAULT '[]',
  voted_at TIMESTAMP NOT NULL DEFAULT NOW(),
  PRIMARY KEY (day, student_id)
);

CREATE TABLE t_p88797006_student_attendance_a.settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE t_p88797006_student_attendance_a.sessions (
  token TEXT PRIMARY KEY,
  student_id TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
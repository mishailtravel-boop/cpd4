import json
import os

import psycopg2

S = os.environ.get('MAIN_DB_SCHEMA', 't_p88797006_student_attendance_a')
CORS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Auth-Token',
    'Access-Control-Max-Age': '86400',
}


def q(v) -> str:
    return "'" + str(v).replace("'", "''") + "'"


def resp(code: int, body: dict) -> dict:
    return {'statusCode': code, 'headers': {**CORS, 'Content-Type': 'application/json'}, 'body': json.dumps(body, ensure_ascii=False)}


def current_user(cur, token):
    if not token:
        return None
    cur.execute(f'SELECT s.id, s.name, s.role FROM {S}.sessions x JOIN {S}.students s ON s.id = x.student_id WHERE x.token = {q(token)}')
    row = cur.fetchone()
    return {'id': row[0], 'name': row[1], 'role': row[2]} if row else None


def feed(cur, me_id):
    cur.execute(f'SELECT id, author_name, text, created_at FROM {S}.posts WHERE hidden = FALSE ORDER BY id DESC LIMIT 300')
    posts = [{'id': i, 'author': a, 'text': t, 'at': c.isoformat() + 'Z', 'fire': 0, 'mine': False, 'comments': []} for i, a, t, c in cur.fetchall()]
    if not posts:
        return {'posts': []}
    by_id = {p['id']: p for p in posts}
    ids = ','.join(str(p['id']) for p in posts)
    cur.execute(f'SELECT post_id, student_id FROM {S}.post_reactions WHERE active = TRUE AND post_id IN ({ids})')
    for pid, sid in cur.fetchall():
        by_id[pid]['fire'] += 1
        if sid == me_id:
            by_id[pid]['mine'] = True
    cur.execute(f'SELECT id, post_id, author_id, author_name, text, created_at FROM {S}.post_comments WHERE hidden = FALSE AND post_id IN ({ids}) ORDER BY id')
    for cid, pid, aid, an, t, c in cur.fetchall():
        by_id[pid]['comments'].append({'id': cid, 'authorId': aid, 'author': an, 'text': t, 'at': c.isoformat() + 'Z'})
    return {'posts': posts}


def handler(event: dict, context) -> dict:
    """Лента «Важно для всех»: сообщения старосты, огоньки и комментарии студентов."""
    if event.get('httpMethod') == 'OPTIONS':
        return {'statusCode': 200, 'headers': CORS, 'body': ''}

    headers = {k.lower(): v for k, v in (event.get('headers') or {}).items()}
    token = headers.get('x-auth-token') or ''
    body = json.loads(event['body']) if event.get('httpMethod') == 'POST' and event.get('body') else {}
    action = body.get('action') or 'list'

    conn = psycopg2.connect(os.environ['DATABASE_URL'])
    conn.autocommit = True
    cur = conn.cursor()
    try:
        user = current_user(cur, token)
        if not user:
            return resp(401, {'error': 'Нужно войти заново'})
        me = user['id']

        if action == 'latest':
            cur.execute(f'SELECT COALESCE(MAX(id), 0) FROM {S}.posts WHERE hidden = FALSE')
            return resp(200, {'lastPostId': cur.fetchone()[0]})

        if action == 'list':
            return resp(200, feed(cur, me))

        if action == 'react':
            pid = int(body.get('postId') or 0)
            cur.execute(
                f'INSERT INTO {S}.post_reactions (post_id, student_id, active) VALUES ({pid}, {q(me)}, TRUE) '
                f'ON CONFLICT (post_id, student_id) DO UPDATE SET active = NOT {S}.post_reactions.active, created_at = NOW()'
            )
        elif action == 'comment':
            pid = int(body.get('postId') or 0)
            text = str(body.get('text') or '').strip()[:1000]
            if not text:
                return resp(400, {'error': 'Пустой комментарий'})
            cur.execute(f'SELECT 1 FROM {S}.posts WHERE id = {pid} AND hidden = FALSE')
            if not cur.fetchone():
                return resp(404, {'error': 'Сообщение не найдено'})
            cur.execute(f'INSERT INTO {S}.post_comments (post_id, author_id, author_name, text) VALUES ({pid}, {q(me)}, {q(user["name"])}, {q(text)})')
        elif action == 'hide_comment':
            cid = int(body.get('id') or 0)
            cond = '' if user['role'] == 'head' else f' AND author_id = {q(me)}'
            cur.execute(f'UPDATE {S}.post_comments SET hidden = TRUE WHERE id = {cid}{cond}')
        elif user['role'] != 'head':
            return resp(403, {'error': 'Писать сообщения может только староста'})
        elif action == 'post':
            text = str(body.get('text') or '').strip()[:4000]
            if not text:
                return resp(400, {'error': 'Пустое сообщение'})
            cur.execute(f'INSERT INTO {S}.posts (author_id, author_name, text) VALUES ({q(me)}, {q(user["name"])}, {q(text)})')
        elif action == 'hide_post':
            cur.execute(f'UPDATE {S}.posts SET hidden = TRUE WHERE id = {int(body.get("id") or 0)}')
        else:
            return resp(400, {'error': 'Неизвестное действие'})
        return resp(200, feed(cur, me))
    finally:
        cur.close()
        conn.close()
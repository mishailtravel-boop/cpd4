import base64
import hashlib
import json
import os
import re
import secrets

import boto3

import psycopg2

S = os.environ.get('MAIN_DB_SCHEMA', 't_p88797006_student_attendance_a')
CORS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Auth-Token',
    'Access-Control-Max-Age': '86400',
}
TIME_RE = re.compile(r'^\d{1,2}:\d{2}$')
DAY_RE = re.compile(r'^\d{4}-\d{2}-\d{2}$')
MAX_FILE = 2600 * 1024


def s3_client():
    return boto3.client('s3', endpoint_url='https://bucket.poehali.dev',
                        aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
                        aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY'])


def cdn_prefix() -> str:
    return f"https://cdn.poehali.dev/projects/{os.environ['AWS_ACCESS_KEY_ID']}/bucket/"


def used_urls(cur) -> set:
    cur.execute(f'SELECT files FROM {S}.homework')
    return {f.get('url') for (raw,) in cur.fetchall() for f in json.loads(raw or '[]')}


def delete_files(cur, urls) -> None:
    prefix = cdn_prefix()
    keys = [u[len(prefix):] for u in set(urls) - used_urls(cur)
            if isinstance(u, str) and u.startswith(prefix + 'homework/')]
    if keys:
        s3_client().delete_objects(Bucket='files', Delete={'Objects': [{'Key': k} for k in keys]})


def q(v) -> str:
    if v is None:
        return 'NULL'
    return "'" + str(v).replace("'", "''") + "'"


def resp(code: int, body: dict) -> dict:
    return {'statusCode': code, 'headers': {**CORS, 'Content-Type': 'application/json'}, 'body': json.dumps(body, ensure_ascii=False)}


def pw_hash(pw: str) -> str:
    return hashlib.sha256(('moya-gruppa-srv:' + pw).encode()).hexdigest()


def uid() -> str:
    return secrets.token_hex(5)


def clean_name(n) -> str:
    return re.sub(r'\s+', ' ', str(n or '')).strip()[:120]


def fetch_state(cur, me_id):
    cur.execute(f'SELECT id, name, role, hours_adjust FROM {S}.students ORDER BY name')
    students, adjust = [], {}
    for sid, name, role, adj in cur.fetchall():
        students.append({'id': sid, 'name': name, 'role': role})
        if adj:
            adjust[sid] = adj
    schedule = {'odd': {}, 'even': {}}
    cur.execute(f'SELECT id, parity, weekday, start_time, end_time, subject, room, kind FROM {S}.lessons ORDER BY start_time')
    for lid, parity, wd, st, en, subj, room, kind in cur.fetchall():
        schedule.setdefault(parity, {}).setdefault(wd, []).append({'id': lid, 'time': st, 'end': en, 'subject': subj, 'room': room, 'kind': kind})
    cur.execute(f'SELECT subject, text, updated_at, files FROM {S}.homework')
    homework = {s: {'text': t, 'updatedAt': u, 'files': json.loads(f or '[]')} for s, t, u, f in cur.fetchall()}
    cur.execute(f"SELECT day, student_id, status, lesson_ids, voted_at FROM {S}.attendance WHERE day >= to_char(NOW() - INTERVAL '200 days', 'YYYY-MM-DD')")
    attendance = {}
    for day, sid, status, lids, at in cur.fetchall():
        attendance.setdefault(day, {})[sid] = {'status': status, 'lessons': json.loads(lids or '[]'), 'at': at.isoformat()}
    cur.execute(f"SELECT 1 FROM {S}.settings WHERE key = 'head_password'")
    has_pw = cur.fetchone() is not None
    if me_id and not any(s['id'] == me_id for s in students):
        me_id = None
    return {
        'meId': me_id, 'students': students, 'schedule': schedule, 'homework': homework,
        'attendance': attendance, 'hoursAdjust': adjust, 'hasPassword': has_pw,
    }


def current_user(cur, token):
    if not token:
        return None
    cur.execute(f'SELECT s.id, s.role FROM {S}.sessions x JOIN {S}.students s ON s.id = x.student_id WHERE x.token = {q(token)}')
    row = cur.fetchone()
    return {'id': row[0], 'role': row[1]} if row else None


def get_pw(cur):
    cur.execute(f"SELECT value FROM {S}.settings WHERE key = 'head_password'")
    row = cur.fetchone()
    return row[0] if row else None


def handler(event: dict, context) -> dict:
    """API приложения «Моя группа»: общее расписание, домашние задания, посещаемость, пропуски и вход старосты по паролю."""
    if event.get('httpMethod') == 'OPTIONS':
        return {'statusCode': 200, 'headers': CORS, 'body': ''}

    headers = {k.lower(): v for k, v in (event.get('headers') or {}).items()}
    token = headers.get('x-auth-token') or ''
    body = {}
    if event.get('httpMethod') == 'POST' and event.get('body'):
        body = json.loads(event['body'])
    action = body.get('action') or 'state'

    conn = psycopg2.connect(os.environ['DATABASE_URL'])
    conn.autocommit = True
    cur = conn.cursor()
    try:
        user = current_user(cur, token)
        me_id = user['id'] if user else None

        if action == 'state':
            return resp(200, fetch_state(cur, me_id))

        if action == 'login':
            name = clean_name(body.get('name'))
            if len(name.split(' ')) < 2:
                return resp(400, {'error': 'Нужны хотя бы фамилия и имя'})
            password = str(body.get('password') or '')
            cur.execute(f'SELECT id, role FROM {S}.students WHERE LOWER(name) = LOWER({q(name)})')
            row = cur.fetchone()
            as_head = bool(body.get('asHead')) or (row is not None and row[1] == 'head')
            if as_head:
                stored = get_pw(cur)
                if stored is None:
                    if len(password) < 4:
                        return resp(400, {'error': 'Пароль — минимум 4 символа'})
                    cur.execute(f"INSERT INTO {S}.settings (key, value) VALUES ('head_password', {q(pw_hash(password))})")
                elif pw_hash(password) != stored:
                    return resp(403, {'error': 'Неверный пароль старосты', 'needPassword': True})
            if row:
                sid = row[0]
                if as_head:
                    cur.execute(f"UPDATE {S}.students SET role = 'head' WHERE id = {q(sid)}")
            else:
                sid = uid()
                cur.execute(f"INSERT INTO {S}.students (id, name, role) VALUES ({q(sid)}, {q(name)}, {q('head' if as_head else 'student')})")
            new_token = secrets.token_hex(24)
            cur.execute(f'INSERT INTO {S}.sessions (token, student_id) VALUES ({q(new_token)}, {q(sid)})')
            return resp(200, {'token': new_token, **fetch_state(cur, sid)})

        if not user:
            return resp(401, {'error': 'Нужно войти заново'})

        if action == 'logout':
            cur.execute(f'DELETE FROM {S}.sessions WHERE token = {q(token)}')
            return resp(200, fetch_state(cur, None))

        if action == 'vote':
            day = str(body.get('day') or '')
            status = body.get('status')
            if not DAY_RE.match(day) or status not in ('all', 'some', 'none'):
                return resp(400, {'error': 'Неверная отметка'})
            lids = [str(x)[:20] for x in (body.get('lessons') or [])][:20] if status == 'some' else []
            cur.execute(
                f'INSERT INTO {S}.attendance (day, student_id, status, lesson_ids, voted_at) '
                f'VALUES ({q(day)}, {q(me_id)}, {q(status)}, {q(json.dumps(lids))}, NOW()) '
                f'ON CONFLICT (day, student_id) DO UPDATE SET status = EXCLUDED.status, lesson_ids = EXCLUDED.lesson_ids, voted_at = NOW()'
            )
            return resp(200, fetch_state(cur, me_id))

        if user['role'] != 'head':
            return resp(403, {'error': 'Это может только староста'})

        if action == 'upload_file':
            name = re.sub(r'[\\/]+', '_', str(body.get('name') or 'file').strip())[:120] or 'file'
            data = base64.b64decode(str(body.get('data') or ''))
            if not data or len(data) > MAX_FILE:
                return resp(400, {'error': 'Файл пустой или больше 2,5 МБ'})
            key = f'homework/{uid()}/{name}'
            s3_client().put_object(Bucket='files', Key=key, Body=data,
                          ContentType=str(body.get('type') or 'application/octet-stream')[:100])
            url = f'{cdn_prefix()}{key}'
            return resp(200, {'file': {'name': name, 'url': url, 'size': len(data)}})

        if action == 'discard_files':
            delete_files(cur, [str(u) for u in (body.get('urls') or [])][:20])
            return resp(200, fetch_state(cur, me_id))

        if action == 'add_student':
            name = clean_name(body.get('name'))
            if len(name.split(' ')) < 2:
                return resp(400, {'error': 'Фамилия и имя — минимум'})
            cur.execute(f'SELECT 1 FROM {S}.students WHERE LOWER(name) = LOWER({q(name)})')
            if cur.fetchone():
                return resp(400, {'error': 'Такой уже есть'})
            cur.execute(f"INSERT INTO {S}.students (id, name, role) VALUES ({q(uid())}, {q(name)}, 'student')")
        elif action == 'remove_student':
            sid = str(body.get('id') or '')
            if sid == me_id:
                return resp(400, {'error': 'Нельзя удалить себя'})
            cur.execute(f'DELETE FROM {S}.sessions WHERE student_id = {q(sid)}')
            cur.execute(f'DELETE FROM {S}.attendance WHERE student_id = {q(sid)}')
            cur.execute(f'DELETE FROM {S}.students WHERE id = {q(sid)}')
        elif action == 'set_hours_adjust':
            adj = int(body.get('adjust') or 0)
            cur.execute(f'UPDATE {S}.students SET hours_adjust = {adj} WHERE id = {q(body.get("id"))}')
        elif action == 'set_homework':
            subject = str(body.get('subject') or '').strip()[:120]
            text = str(body.get('text') or '').strip()[:4000]
            if not subject:
                return resp(400, {'error': 'Нет предмета'})
            files = [
                {'name': str(f.get('name'))[:120], 'url': str(f.get('url')), 'size': int(f.get('size') or 0)}
                for f in (body.get('files') or [])[:20]
                if isinstance(f, dict) and str(f.get('url') or '').startswith('https://cdn.poehali.dev/')
            ]
            cur.execute(f'SELECT files FROM {S}.homework WHERE subject = {q(subject)}')
            old = cur.fetchone()
            old_urls = [f.get('url') for f in json.loads(old[0] or '[]')] if old else []
            if text or files:
                cur.execute(
                    f'INSERT INTO {S}.homework (subject, text, updated_at, files) VALUES ({q(subject)}, {q(text)}, {q(body.get("updatedAt") or "")}, {q(json.dumps(files, ensure_ascii=False))}) '
                    f'ON CONFLICT (subject) DO UPDATE SET text = EXCLUDED.text, updated_at = EXCLUDED.updated_at, files = EXCLUDED.files'
                )
            else:
                cur.execute(f'DELETE FROM {S}.homework WHERE subject = {q(subject)}')
            delete_files(cur, old_urls)
        elif action in ('add_lesson', 'update_lesson'):
            parity = body.get('parity')
            wd = str(body.get('weekday') or '')
            st = str(body.get('time') or '')
            en = str(body.get('end') or '')
            subject = str(body.get('subject') or '').strip()[:120]
            room = str(body.get('room') or '').strip()[:60]
            if room.lower().startswith('ауд'):
                room = room[3:].lstrip('. ').strip()
            kind = body.get('kind') if body.get('kind') in ('lecture', 'seminar') else ''
            if parity not in ('odd', 'even') or wd not in ('1', '2', '3', '4', '5', '6') or not TIME_RE.match(st) or not TIME_RE.match(en) or not subject:
                return resp(400, {'error': 'Проверьте поля пары'})
            if action == 'update_lesson':
                cur.execute(
                    f'UPDATE {S}.lessons SET parity = {q(parity)}, weekday = {q(wd)}, start_time = {q(st.zfill(5))}, end_time = {q(en.zfill(5))}, '
                    f'subject = {q(subject)}, room = {q(room)}, kind = {q(kind)} WHERE id = {q(body.get("id"))}'
                )
                if cur.rowcount == 0:
                    return resp(404, {'error': 'Пара не найдена'})
            else:
                cur.execute(
                    f'INSERT INTO {S}.lessons (id, parity, weekday, start_time, end_time, subject, room, kind) '
                    f'VALUES ({q(uid())}, {q(parity)}, {q(wd)}, {q(st.zfill(5))}, {q(en.zfill(5))}, {q(subject)}, {q(room)}, {q(kind)})'
                )
        elif action == 'remove_lesson':
            cur.execute(f'DELETE FROM {S}.lessons WHERE id = {q(body.get("id"))}')
        elif action == 'set_password':
            pw = str(body.get('password') or '')
            if len(pw) < 4:
                return resp(400, {'error': 'Минимум 4 символа'})
            cur.execute(
                f"INSERT INTO {S}.settings (key, value) VALUES ('head_password', {q(pw_hash(pw))}) "
                f'ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value'
            )
        else:
            return resp(400, {'error': 'Неизвестное действие'})

        return resp(200, fetch_state(cur, me_id))
    finally:
        cur.close()
        conn.close()

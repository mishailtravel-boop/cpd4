import { useCallback, useEffect, useState } from "react";
import func2url from "../../backend/func2url.json";

const API = (func2url as Record<string, string>).feed;
const SEEN_KEY = "moya-gruppa-feed-seen";
const POLL_MS = 60_000;

export function useFeedBadge(onFeed: boolean) {
  const [latest, setLatest] = useState(0);
  const [seen, setSeen] = useState(0);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setSeen(Number(localStorage.getItem(SEEN_KEY) || 0));
    setLoaded(true);
  }, []);

  const markSeen = useCallback((id: number) => {
    setLatest((l) => Math.max(l, id));
    setSeen((s) => {
      const next = Math.max(s, id);
      localStorage.setItem(SEEN_KEY, String(next));
      return next;
    });
  }, []);

  useEffect(() => {
    if (onFeed) return;
    let stop = false;
    const check = async () => {
      if (document.visibilityState !== "visible") return;
      const res = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Auth-Token": localStorage.getItem("moya-gruppa-token") ?? "" },
        body: JSON.stringify({ action: "latest" }),
      }).catch(() => null);
      if (!res?.ok || stop) return;
      const json = await res.json();
      setLatest(Number(json.lastPostId) || 0);
    };
    check();
    const t = setInterval(check, POLL_MS);
    const onVisible = () => document.visibilityState === "visible" && check();
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      stop = true;
      clearInterval(t);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [onFeed]);

  return { unread: loaded && latest > seen, markSeen };
}

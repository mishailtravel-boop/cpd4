import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { PARITY_ANCHOR, type AppData } from "@/lib/schedule";
import func2url from "../../backend/func2url.json";

const API = (func2url as Record<string, string>).group;
const TOKEN_KEY = "moya-gruppa-token";
const KNOWN_KEY = "moya-gruppa-known";

export interface KnownAccount {
  token: string;
  name: string;
  role: "head" | "student";
}

function readKnown(): KnownAccount[] {
  try {
    const v = JSON.parse(localStorage.getItem(KNOWN_KEY) ?? "[]");
    return Array.isArray(v) ? v.filter((a) => a && a.token && a.name) : [];
  } catch {
    return [];
  }
}

function writeKnown(list: KnownAccount[]) {
  localStorage.setItem(KNOWN_KEY, JSON.stringify(list.slice(0, 5)));
}

type ServerData = Omit<AppData, "parityAnchor"> & { token?: string; error?: string };

export class ApiError extends Error {}

interface StoreValue {
  data: AppData | null;
  loaded: boolean;
  failed: boolean;
  now: Date | null;
  call: (action: string, payload?: Record<string, unknown>) => Promise<AppData>;
  refresh: () => Promise<void>;
  known: KnownAccount[];
  resume: (account: KnownAccount) => Promise<boolean>;
  forget: (token: string) => void;
  signOut: () => void;
}

const StoreContext = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const [now, setNow] = useState<Date | null>(null);
  const [known, setKnown] = useState<KnownAccount[]>([]);

  const request = useCallback(async (action: string, payload: Record<string, unknown> = {}) => {
    const token = localStorage.getItem(TOKEN_KEY) ?? "";
    const res = await fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Auth-Token": token },
      body: JSON.stringify({ action, ...payload }),
    });
    const json = (await res.json()) as ServerData;
    if (res.status === 401) {
      if (token) {
        const rest = readKnown().filter((a) => a.token !== token);
        writeKnown(rest);
        setKnown(rest);
      }
      localStorage.removeItem(TOKEN_KEY);
      setData((d) => (d ? { ...d, meId: null } : d));
    }
    if (!res.ok) throw new ApiError(json.error || "Не получилось, попробуйте ещё раз");
    if (json.token) localStorage.setItem(TOKEN_KEY, json.token);
    if (action === "logout") localStorage.removeItem(TOKEN_KEY);
    const active = localStorage.getItem(TOKEN_KEY);
    const me = json.students?.find((s) => s.id === json.meId);
    if (active && me) {
      const list = [{ token: active, name: me.name, role: me.role }, ...readKnown().filter((a) => a.token !== active && a.name !== me.name)];
      writeKnown(list);
      setKnown(list);
    }
    const next: AppData = { ...json, parityAnchor: PARITY_ANCHOR };
    setData(next);
    return next;
  }, []);

  const refresh = useCallback(async () => {
    try {
      await request("state");
      setFailed(false);
    } catch {
      setFailed(true);
    }
  }, [request]);

  const resume = useCallback(
    async (account: KnownAccount) => {
      localStorage.setItem(TOKEN_KEY, account.token);
      try {
        const next = await request("state");
        return !!next.meId;
      } catch {
        return false;
      }
    },
    [request],
  );

  const forget = useCallback((token: string) => {
    const rest = readKnown().filter((a) => a.token !== token);
    writeKnown(rest);
    setKnown(rest);
  }, []);

  const signOut = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY);
    setData((d) => (d ? { ...d, meId: null } : d));
  }, []);

  useEffect(() => {
    setKnown(readKnown());
    navigator.storage?.persist?.().catch(() => {});
    setNow(new Date());
    refresh().finally(() => setLoaded(true));
    const t = setInterval(() => setNow(new Date()), 30_000);
    const onVisible = () => {
      if (document.visibilityState === "visible") refresh();
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      clearInterval(t);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [refresh]);

  const call = useCallback(
    async (action: string, payload?: Record<string, unknown>) => {
      try {
        return await request(action, payload);
      } catch (e) {
        if (e instanceof ApiError) throw e;
        toast.error("Нет связи. Проверьте интернет.");
        throw e;
      }
    },
    [request],
  );

  const value = useMemo(
    () => ({ data, loaded, failed, now, call, refresh, known, resume, forget, signOut }),
    [data, loaded, failed, now, call, refresh, known, resume, forget, signOut],
  );
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}

/** Только для экранов, которые рендерятся после загрузки */
export function useReadyStore() {
  const { data, now, call, refresh } = useStore();
  if (!data || !now) throw new Error("store not ready");
  const me = data.students.find((s) => s.id === data.meId) ?? null;
  return { data, now, call, refresh, me, isHead: me?.role === "head" };
}

/** Вызов с показом ошибки сервера во всплывашке */
export async function safe<T>(p: Promise<T>): Promise<T | null> {
  try {
    return await p;
  } catch (e) {
    if (e instanceof ApiError) toast.error(e.message);
    return null;
  }
}

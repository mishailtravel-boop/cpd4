export type Parity = "odd" | "even";
export type Role = "student" | "head";
export type VoteStatus = "all" | "some" | "none";

export interface Lesson {
  id: string;
  time: string; // "09:00"
  end?: string;
  subject: string;
  room: string;
  kind?: LessonKind;
}

export type LessonKind = "" | "lecture" | "seminar";

export const KIND_LABEL: Record<string, string> = { lecture: "Лекция", seminar: "Семинар" };

export function lessonPlace(l: Pick<Lesson, "room" | "kind">) {
  const room = l.room.trim();
  return [room ? (/^ауд/i.test(room) ? room : `ауд. ${room}`) : "ауд. —", KIND_LABEL[l.kind ?? ""]].filter(Boolean).join(" · ");
}

/** weekday 1..6 (Пн..Сб) -> lessons */
export type WeekSchedule = Record<string, Lesson[]>;

export interface Student {
  id: string;
  name: string;
  role: Role;
}

export interface Vote {
  status: VoteStatus;
  lessons: string[]; // lesson ids the student attends (for "some")
  at: string;
}

export interface HomeworkFile {
  name: string;
  url: string;
  size: number;
}

export interface Homework {
  text: string;
  updatedAt: string;
  files?: HomeworkFile[];
}

export interface AppData {
  meId: string | null;
  students: Student[];
  schedule: Record<Parity, WeekSchedule>;
  parityAnchor: { monday: string; parity: Parity };
  homework: Record<string, Homework>;
  attendance: Record<string, Record<string, Vote>>;
  hoursAdjust?: Record<string, number>;
  hasPassword?: boolean;
}

export async function hashPassword(pw: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`moya-gruppa:${pw}`));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export const LESSON_MINUTES = 90;
export const SWITCH_HOUR = 18;

export const WEEKDAYS_SHORT = ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"];
export const WEEKDAYS_FULL = [
  "Воскресенье",
  "Понедельник",
  "Вторник",
  "Среда",
  "Четверг",
  "Пятница",
  "Суббота",
];
const WEEKDAYS_ACC = [
  "В воскресенье",
  "В понедельник",
  "Во вторник",
  "В среду",
  "В четверг",
  "В пятницу",
  "В субботу",
];
export const MONTHS_SHORT = ["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"];
const MONTHS_GEN = [
  "января",
  "февраля",
  "марта",
  "апреля",
  "мая",
  "июня",
  "июля",
  "августа",
  "сентября",
  "октября",
  "ноября",
  "декабря",
];

export const uid = () => Math.random().toString(36).slice(2, 10);

export function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

export function addDays(d: Date, n: number) {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

export function iso(d: Date) {
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function fromIso(s: string) {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function mondayOf(d: Date) {
  const x = startOfDay(d);
  const wd = (x.getDay() + 6) % 7; // 0 = Monday
  return addDays(x, -wd);
}

/**
 * Какой день показывается на главной: до 18:00 — сегодняшний,
 * после 18:00 — следующий; выходные пропускаются (пятница 18:00 -> понедельник).
 */
export function targetDate(now: Date) {
  let d = startOfDay(now);
  if (now.getHours() >= SWITCH_HOUR) d = addDays(d, 1);
  while (d.getDay() === 0 || d.getDay() === 6) d = addDays(d, 1);
  return d;
}

/** Неделя с 26 октября 2026 — нечётная, дальше недели чередуются */
export const PARITY_ANCHOR: { monday: string; parity: Parity } = { monday: "2026-10-26", parity: "odd" };

export function weekParity(date: Date, anchor: { monday: string; parity: Parity } = PARITY_ANCHOR): Parity {
  const diffDays = Math.round((mondayOf(date).getTime() - fromIso(anchor.monday).getTime()) / 86400000);
  const weeks = Math.round(diffDays / 7);
  const same = Math.abs(weeks) % 2 === 0;
  if (same) return anchor.parity;
  return anchor.parity === "odd" ? "even" : "odd";
}

export const PARITY_LABEL: Record<Parity, string> = { even: "Чётная", odd: "Нечётная" };

export function lessonsFor(data: AppData, date: Date): Lesson[] {
  const p = weekParity(date);
  const list = data.schedule[p][String(date.getDay())] ?? [];
  return [...list].sort((a, b) => a.time.localeCompare(b.time));
}

export function toMinutes(t: string) {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + (m || 0);
}

export function lessonEnd(l: Pick<Lesson, "time" | "end">) {
  return l.end || endTime(l.time);
}

export function endTime(t: string) {
  const total = toMinutes(t) + LESSON_MINUTES;
  return `${String(Math.floor(total / 60) % 24).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
}

export function dayTitle(date: Date, now: Date) {
  const today = startOfDay(now);
  if (iso(date) === iso(today)) return "Сегодня";
  if (iso(date) === iso(addDays(today, 1))) return "Завтра";
  return WEEKDAYS_ACC[date.getDay()];
}

const COUNT_WORDS = ["нет", "одна", "две", "три", "четыре", "пять", "шесть", "семь", "восемь"];

export function lessonsWord(n: number): [string, string] {
  if (n === 0) return ["нет", "пар"];
  const w = COUNT_WORDS[n] ?? String(n);
  const noun = n === 1 ? "пара" : n >= 2 && n <= 4 ? "пары" : "пар";
  return [w, noun];
}

export function prettyDate(d: Date) {
  return `${d.getDate()} ${MONTHS_GEN[d.getMonth()]}`;
}

export function hoursWord(n: number) {
  const a = n % 10;
  const b = n % 100;
  if (a === 1 && b !== 11) return "час";
  if (a >= 2 && a <= 4 && (b < 12 || b > 14)) return "часа";
  return "часов";
}

export function missedLessons(data: AppData, studentId: string, dateIso: string) {
  const vote = data.attendance[dateIso]?.[studentId];
  if (!vote) return null;
  const lessons = lessonsFor(data, fromIso(dateIso));
  if (vote.status === "all") return 0;
  if (vote.status === "none") return lessons.length;
  const attended = lessons.filter((l) => vote.lessons.includes(l.id)).length;
  return Math.max(0, lessons.length - attended);
}

export function totalMissedHours(data: AppData, studentId: string) {
  let lessons = 0;
  for (const day of Object.keys(data.attendance)) {
    lessons += missedLessons(data, studentId, day) ?? 0;
  }
  const auto = lessons * 2;
  const adjust = data.hoursAdjust?.[studentId] ?? 0;
  return { lessons, auto, adjust, hours: Math.max(0, auto + adjust) };
}

/* ---------- Демо-данные для первого запуска ---------- */

const L = (time: string, subject: string, room: string): Lesson => ({ id: uid(), time, subject, room });

function seedSchedule(): Record<Parity, WeekSchedule> {
  return {
    odd: {
      "1": [L("09:00", "Матанализ", "ауд. 214"), L("10:45", "Физика", "ауд. 101"), L("12:40", "Программирование", "ауд. 305")],
      "2": [L("09:00", "Английский язык", "ауд. 412"), L("10:45", "Дискретная математика", "ауд. 214"), L("12:40", "История", "ауд. 118")],
      "3": [L("09:00", "Матанализ", "ауд. 214"), L("10:45", "Физика", "ауд. 101"), L("12:40", "Программирование", "ауд. 305"), L("14:25", "История", "ауд. 118")],
      "4": [L("10:45", "Алгоритмы", "ауд. 307"), L("12:40", "Физкультура", "спортзал"), L("14:25", "Философия", "ауд. 220")],
      "5": [L("09:00", "Программирование", "ауд. 305"), L("10:45", "Английский язык", "ауд. 412")],
      "6": [],
    },
    even: {
      "1": [L("09:00", "Физика", "ауд. 101"), L("10:45", "Матанализ", "ауд. 214"), L("12:40", "Алгоритмы", "ауд. 307")],
      "2": [L("10:45", "Дискретная математика", "ауд. 214"), L("12:40", "Английский язык", "ауд. 412")],
      "3": [L("09:00", "Матанализ", "ауд. 214"), L("10:45", "Физика", "ауд. 101"), L("12:40", "Программирование", "ауд. 305"), L("14:25", "История", "ауд. 118")],
      "4": [L("09:00", "Философия", "ауд. 220"), L("10:45", "Алгоритмы", "ауд. 307"), L("12:40", "Физкультура", "спортзал")],
      "5": [L("09:00", "Программирование", "ауд. 305"), L("10:45", "Дискретная математика", "ауд. 214"), L("12:40", "История", "ауд. 118")],
      "6": [],
    },
  };
}

const SEED_NAMES = [
  "Алексеева Мария Игоревна",
  "Белов Никита Сергеевич",
  "Воронцова Анна Павловна",
  "Григорьев Илья Андреевич",
  "Долгова Екатерина Олеговна",
  "Ершов Максим Дмитриевич",
  "Жукова Полина Артёмовна",
  "Зайцев Кирилл Романович",
  "Иванова Софья Викторовна",
  "Козлов Артём Евгеньевич",
  "Лебедева Дарья Михайловна",
  "Морозов Глеб Алексеевич",
];

export function seedData(now: Date): AppData {
  const students: Student[] = SEED_NAMES.map((name) => ({ id: uid(), name, role: "student" }));
  const data: AppData = {
    meId: null,
    students,
    schedule: seedSchedule(),
    parityAnchor: PARITY_ANCHOR,
    homework: {
      "Матанализ": { text: "Демидович: № 1215–1230. Подготовиться к самостоятельной по пределам.", updatedAt: iso(now) },
      "Физика": { text: "Лабораторная №3 — оформить отчёт, ответить на контрольные вопросы 1–6.", updatedAt: iso(now) },
      "Программирование": { text: "Дописать задачу про связный список, залить в репозиторий группы до 23:59.", updatedAt: iso(now) },
      "Английский язык": { text: "Unit 7, упр. 3–5 письменно, выучить слова к словарному диктанту.", updatedAt: iso(now) },
    },
    attendance: {},
  };

  // Немного истории: прошлые будние дни + сегодняшние голоса
  const pattern: VoteStatus[] = ["all", "all", "some", "all", "none", "all", "some", "all", "all", "none", "all", "some"];
  const target = targetDate(now);
  const days: Date[] = [];
  let d = addDays(target, -1);
  while (days.length < 6) {
    if (d.getDay() !== 0 && d.getDay() !== 6) days.push(d);
    d = addDays(d, -1);
  }
  days.push(target);
  days.forEach((day, di) => {
    const lessons = lessonsFor(data, day);
    if (!lessons.length) return;
    const key = iso(day);
    data.attendance[key] = {};
    students.forEach((s, si) => {
      if (day === target && si % 4 === 3) return; // кто-то ещё не отметился
      const st = di === days.length - 1 ? pattern[si] : (si + di) % 7 === 0 ? "none" : (si * 3 + di) % 5 === 0 ? "some" : "all";
      data.attendance[key][s.id] = {
        status: st,
        lessons: st === "some" ? lessons.slice(0, Math.max(1, lessons.length - 1)).map((l) => l.id) : [],
        at: key,
      };
    });
  });
  return data;
}

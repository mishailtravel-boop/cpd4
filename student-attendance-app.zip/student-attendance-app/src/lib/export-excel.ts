import { fromIso, lessonsFor, missedLessons, prettyDate, totalMissedHours, type AppData } from "@/lib/schedule";

const STATUS: Record<string, string> = { all: "Был на всех", some: "Частично", none: "Не был" };

export async function exportAttendance(data: AppData) {
  const { default: ExcelJS } = await import("exceljs");
  const wb = new ExcelJS.Workbook();
  const students = [...data.students].sort((a, b) => a.name.localeCompare(b.name, "ru"));
  const days = Object.keys(data.attendance).sort();
  const bold = { bold: true };

  const summary = wb.addWorksheet("Пропуски");
  summary.columns = [
    { header: "ФИО", width: 36 },
    { header: "Роль", width: 12 },
    { header: "Пропущено пар", width: 16 },
    { header: "Часы (авто)", width: 13 },
    { header: "Поправка", width: 11 },
    { header: "Итого часов", width: 13 },
  ];
  summary.getRow(1).font = bold;
  for (const s of students) {
    const t = totalMissedHours(data, s.id);
    summary.addRow([s.name, s.role === "head" ? "Староста" : "Студент", t.lessons, t.auto, t.adjust, t.hours]);
  }

  const table = wb.addWorksheet("Отметки по дням");
  table.columns = [{ header: "ФИО", width: 36 }, ...days.map((d) => ({ header: prettyDate(fromIso(d)), width: 14 }))];
  table.getRow(1).font = bold;
  for (const s of students) {
    table.addRow([
      s.name,
      ...days.map((d) => {
        const m = missedLessons(data, s.id, d);
        return m === null ? "—" : m === 0 ? "✓" : `−${m}`;
      }),
    ]);
  }
  table.addRow([]);
  table.addRow(["✓ — был на всех парах, −N — пропустил N пар, — — не отметился"]);

  const log = wb.addWorksheet("Подробно");
  log.columns = [
    { header: "Дата", width: 12 },
    { header: "ФИО", width: 36 },
    { header: "Отметка", width: 14 },
    { header: "Пропущенные пары", width: 50 },
  ];
  log.getRow(1).font = bold;
  const byId = new Map(students.map((s) => [s.id, s.name]));
  for (const d of days) {
    const lessons = lessonsFor(data, fromIso(d));
    for (const [sid, v] of Object.entries(data.attendance[d])) {
      const name = byId.get(sid);
      if (!name) continue;
      const missed =
        v.status === "all" ? [] : v.status === "none" ? lessons : lessons.filter((l) => !v.lessons.includes(l.id));
      log.addRow([d.split("-").reverse().join("."), name, STATUS[v.status] ?? v.status, missed.map((l) => `${l.time} ${l.subject}`).join(", ")]);
    }
  }

  const hw = wb.addWorksheet("Домашние задания");
  hw.columns = [
    { header: "Предмет", width: 26 },
    { header: "Задание", width: 80 },
    { header: "Обновлено", width: 12 },
  ];
  hw.getRow(1).font = bold;
  for (const [subject, h] of Object.entries(data.homework)) hw.addRow([subject, h.text, h.updatedAt]);

  const buf = await wb.xlsx.writeBuffer();
  const blob = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const t = new Date();
  a.href = url;
  a.download = `Посещаемость_${String(t.getDate()).padStart(2, "0")}.${String(t.getMonth() + 1).padStart(2, "0")}.${t.getFullYear()}.xlsx`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

import { createFileRoute } from "@tanstack/react-router";
import AppShell from "@/components/app/AppShell";
import { StoreProvider } from "@/hooks/use-store";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  return (
    <StoreProvider>
      <AppShell />
    </StoreProvider>
  );
}

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import Icon from "@/components/ui/icon";
import { ApiError, useReadyStore, useStore, type KnownAccount } from "@/hooks/use-store";

export default function Onboarding() {
  const { data, call } = useReadyStore();
  const { known, resume, forget } = useStore();
  const [manual, setManual] = useState(false);
  const [resuming, setResuming] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [head, setHead] = useState(false);
  const [error, setError] = useState("");
  const [password, setPassword] = useState("");
  const [password2, setPassword2] = useState("");
  const [busy, setBusy] = useState(false);
  const hasPassword = !!data.hasPassword;

  const clean = name.trim().replace(/\s+/g, " ");
  const existing = data.students.find((s) => s.name.toLowerCase() === clean.toLowerCase());
  const asHead = head || existing?.role === "head";

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (clean.split(" ").length < 2) {
      setError("Нужны хотя бы фамилия и имя");
      return;
    }
    if (asHead && !hasPassword) {
      if (password.length < 4) return setError("Пароль — минимум 4 символа");
      if (password !== password2) return setError("Пароли не совпадают");
    }
    if (asHead && hasPassword && !password) return setError("Введите пароль старосты");
    setBusy(true);
    try {
      await call("login", { name: clean, asHead, password });
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message);
        if (err.message.includes("пароль")) setHead(true);
      }
    } finally {
      setBusy(false);
    }
  };

  const enter = async (a: KnownAccount) => {
    setResuming(a.token);
    const ok = await resume(a);
    setResuming(null);
    if (!ok) {
      setName(a.name);
      setError("Вход устарел — войдите ещё раз");
      setManual(true);
    }
  };

  if (known.length > 0 && !manual) {
    return (
      <div className="flex min-h-[100dvh] flex-col justify-between gap-10 px-5 py-8 sm:px-12 sm:py-10">
        <div className="font-head text-[1.9rem] font-bold uppercase leading-none">Моя группа</div>
        <div className="mx-auto w-full max-w-xl animate-rise">
          <h1 className="font-head text-[3.6rem] sm:text-[84px] font-bold uppercase leading-[0.95] tracking-[-0.01em]">
            С возвра-
            <br />
            <span className="text-primary">щением</span>
          </h1>
          <p className="mt-4 text-[1.1rem]">Выберите, кто вы — вход в один тап.</p>
          <ul className="mt-8 flex flex-col gap-2">
            {known.map((a) => (
              <li key={a.token} className="flex items-center gap-2 rounded-[18px] bg-card p-2">
                <button
                  type="button"
                  disabled={!!resuming}
                  onClick={() => enter(a)}
                  className="flex min-w-0 flex-1 items-center gap-3 rounded-[14px] px-3 py-2.5 text-left transition-colors hover:bg-secondary disabled:opacity-60"
                >
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-primary font-head text-lg font-bold text-primary-foreground">
                    {a.name.split(" ").slice(0, 2).map((w) => w[0]).join("")}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-semibold">{a.name}</span>
                    <span className="text-xs text-muted-foreground">{a.role === "head" ? "Староста" : "Студент"}</span>
                  </span>
                  <Icon name={resuming === a.token ? "Loader2" : "ChevronRight"} size={20} className={resuming === a.token ? "animate-spin" : "text-muted-foreground"} />
                </button>
                <button
                  type="button"
                  onClick={() => forget(a.token)}
                  aria-label="Забыть на этом устройстве"
                  title="Забыть на этом устройстве"
                  className="grid h-10 w-10 shrink-0 place-items-center rounded-full text-muted-foreground hover:bg-secondary hover:text-destructive"
                >
                  <Icon name="X" size={16} />
                </button>
              </li>
            ))}
          </ul>
          <button
            type="button"
            onClick={() => setManual(true)}
            className="mt-4 w-full rounded-full bg-secondary py-4 text-sm font-semibold uppercase tracking-[0.1em] hover:bg-accent"
          >
            Войти под другим именем
          </button>
        </div>
        <p className="text-center text-xs text-muted-foreground">Расписание сменяется каждый день в 18:00</p>
      </div>
    );
  }

  return (
    <div className="flex min-h-[100dvh] flex-col justify-between gap-10 px-5 py-8 sm:px-12 sm:py-10">
      <div className="font-head text-[1.9rem] font-bold uppercase leading-none">Моя группа</div>

      <form onSubmit={submit} className="mx-auto w-full max-w-xl animate-rise">
        <h1 className="font-head text-[3.6rem] sm:text-[84px] font-bold uppercase leading-[0.95] tracking-[-0.01em]">
          Кто
          <br />
          <span className="text-primary">ты?</span>
        </h1>
        <p className="mt-4 max-w-[34ch] text-[1.1rem]">
          Впиши ФИО полностью — по нему староста увидит твою отметку и пропуски.
        </p>

        <div className="mt-8 rounded-[18px] bg-card p-5 sm:p-6">
          <label htmlFor="fio" className="label-caps text-muted-foreground">
            Фамилия Имя Отчество
          </label>
          <Input
            id="fio"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              setError("");
            }}
            autoComplete="name"
            placeholder="Иванов Иван Иванович"
            className="mt-2 h-14 rounded-full border-0 bg-secondary px-5 text-lg"
          />
          {error && <p className="mt-2 text-sm text-destructive">{error}</p>}

          <label className="mt-5 flex cursor-pointer items-center justify-between gap-4 rounded-full bg-secondary px-5 py-3">
            <span className="text-sm font-medium">Я староста группы</span>
            <Switch
              checked={asHead}
              disabled={existing?.role === "head"}
              onCheckedChange={(v) => {
                setHead(v);
                setError("");
              }}
            />
          </label>

          {asHead && (
            <div className="mt-5">
              <label htmlFor="pw" className="label-caps text-muted-foreground">
                {hasPassword ? "Пароль старосты" : "Придумайте пароль старосты"}
              </label>
              <Input
                id="pw"
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError("");
                }}
                autoComplete={hasPassword ? "current-password" : "new-password"}
                placeholder="••••"
                className="mt-2 h-14 rounded-full border-0 bg-secondary px-5 text-lg"
              />
              {!hasPassword && (
                <>
                  <Input
                    type="password"
                    value={password2}
                    onChange={(e) => {
                      setPassword2(e.target.value);
                      setError("");
                    }}
                    autoComplete="new-password"
                    placeholder="Повторите пароль"
                    className="mt-2 h-14 rounded-full border-0 bg-secondary px-5 text-lg"
                  />
                  <p className="mt-2 text-xs text-muted-foreground">
                    Запомните его — дальше по нему будете входить как староста.
                  </p>
                </>
              )}
            </div>
          )}
        </div>

        <button
          type="submit"
          disabled={busy}
          className="mt-5 disabled:opacity-60 w-full rounded-full bg-primary py-4 text-sm font-semibold uppercase tracking-[0.1em] text-primary-foreground transition-transform active:scale-[0.98]"
        >
          Войти
        </button>
        {known.length > 0 && (
          <button
            type="button"
            onClick={() => {
              setManual(false);
              setError("");
            }}
            className="mt-3 w-full text-center text-sm text-muted-foreground hover:text-foreground"
          >
            ← К сохранённым входам
          </button>
        )}
      </form>

      <p className="text-center text-xs text-muted-foreground">Расписание сменяется каждый день в 18:00</p>
    </div>
  );
}

import { useState } from "react";
import LessonCard from "@/components/app/LessonCard";
import HomeworkDialog from "@/components/app/HomeworkDialog";
import { useReadyStore } from "@/hooks/use-store";
import {
  dayTitle,
  iso,
  lessonsFor,
  lessonsWord,
  lessonEnd,
  prettyDate,
  targetDate,
  toMinutes,
  WEEKDAYS_FULL,
  type Lesson,
} from "@/lib/schedule";

interface Props {
  date: Date;
  onAttend: () => void;
}

export default function HomeScreen({ date, onAttend }: Props) {
  const { data, now } = useReadyStore();
  const [open, setOpen] = useState<Lesson | null>(null);
  const lessons = lessonsFor(data, date);
  const isTarget = iso(date) === iso(targetDate(now));
  const isToday = iso(date) === iso(now);
  const [count, noun] = lessonsWord(lessons.length);
  const title = dayTitle(date, now);

  const nowMin = now.getHours() * 60 + now.getMinutes();
  let nextMarked = false;
  const stateOf = (l: Lesson, i: number): "now" | "next" | "past" | "idle" => {
    if (!isToday) return i === 0 && isTarget ? "next" : "idle";
    const s = toMinutes(l.time);
    const e = toMinutes(lessonEnd(l));
    if (nowMin >= s && nowMin < e) return "now";
    if (nowMin >= e) return "past";
    if (!nextMarked) {
      nextMarked = true;
      return "next";
    }
    return "idle";
  };
  const states = lessons.map(stateOf);
  // если ничего не идёт сейчас — подсвечиваем ближайшую
  const highlight = states.includes("now") ? "now" : "next";

  const subtitle = isTarget
    ? now.getHours() >= 18 || !isToday
      ? `Расписание на ${prettyDate(date)} уже здесь. Держится до 18:00. Жми на пару — там домашка.`
      : "Обновится в 18:00. Жми на пару — там домашка."
    : `${WEEKDAYS_FULL[date.getDay()]}, ${prettyDate(date)}. Жми на пару — там домашка.`;

  return (
    <div className="grid min-h-0 gap-6 grid-cols-1 [&>*]:min-w-0 md:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)] md:gap-10">
      <div className="flex flex-col justify-center gap-4 sm:gap-[18px] animate-rise">
        <h1 className="font-head text-[3.4rem] sm:text-[4.2rem] lg:text-[84px] font-bold uppercase leading-[0.95] tracking-[-0.01em]">
          {title}
          <br />
          {lessons.length === 0 ? (
            <>
              пар
              <br />
              <span className="text-primary">нет</span>
            </>
          ) : (
            <>
              {count}
              <br />
              {noun}
            </>
          )}
        </h1>
        <p className="max-w-[30ch] text-[1.05rem] sm:text-[1.1rem] text-foreground">{subtitle}</p>
        {lessons.length > 0 && isTarget && (
          <button
            type="button"
            onClick={onAttend}
            className="self-start rounded-full bg-primary px-6 py-[13px] text-[0.8rem] font-semibold uppercase tracking-[0.1em] text-primary-foreground transition-transform hover:scale-[1.03] active:scale-95"
          >
            Отметиться
          </button>
        )}
      </div>

      <div className="flex flex-col justify-center gap-2.5 bg-card p-4 sm:p-[26px] md:min-h-0 md:overflow-y-auto no-scrollbar">
        {lessons.length === 0 ? (
          <div className="py-10 text-center">
            <div className="font-head text-3xl font-bold uppercase">Выходной</div>
            <p className="mt-2 text-muted-foreground">Отдыхай. Домашка подождёт.</p>
          </div>
        ) : (
          lessons.map((l, i) => {
            const st = states[i];
            return (
              <LessonCard
                key={l.id}
                index={i}
                lesson={l}
                state={st}
                highlight={st === highlight}
                hasHomework={!!data.homework[l.subject]}
                onOpen={() => setOpen(l)}
              />
            );
          })
        )}
      </div>

      <HomeworkDialog lesson={open} onClose={() => setOpen(null)} />
    </div>
  );
}
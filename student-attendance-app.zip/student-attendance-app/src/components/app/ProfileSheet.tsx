import { useState } from "react";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import Icon from "@/components/ui/icon";
import { safe, useReadyStore, useStore } from "@/hooks/use-store";
import { cn } from "@/lib/utils";
import { endTime, lessonEnd, lessonPlace, type LessonKind, type Parity } from "@/lib/schedule";
import { exportAttendance } from "@/lib/export-excel";

const DAYS: [string, string][] = [
  ["1", "Пн"],
  ["2", "Вт"],
  ["3", "Ср"],
  ["4", "Чт"],
  ["5", "Пт"],
  ["6", "Сб"],
];

export default function ProfileSheet({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const { data, call, me, isHead } = useReadyStore();
  const { signOut } = useStore();
  const [parity, setParity] = useState<Parity>("even");
  const [day, setDay] = useState("1");
  const [time, setTime] = useState("09:00");
  const [end, setEnd] = useState("10:30");
  const [subject, setSubject] = useState("");
  const [room, setRoom] = useState("");
  const [kind, setKind] = useState<LessonKind>("lecture");
  const [editId, setEditId] = useState<string | null>(null);

  const lessons = [...(data.schedule[parity][day] ?? [])].sort((a, b) => a.time.localeCompare(b.time));

  const [pwOpen, setPwOpen] = useState(false);
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [pwMsg, setPwMsg] = useState("");
  const [exporting, setExporting] = useState(false);

  const doExport = async () => {
    setExporting(true);
    try {
      await exportAttendance(data);
    } finally {
      setExporting(false);
    }
  };

  const savePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pw.length < 4) return setPwMsg("Минимум 4 символа");
    if (pw !== pw2) return setPwMsg("Пароли не совпадают");
    const ok = await safe(call("set_password", { password: pw }));
    if (!ok) return;
    setPw("");
    setPw2("");
    setPwOpen(false);
    setPwMsg("Пароль изменён");
  };

  const addLesson = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !/^\d{1,2}:\d{2}$/.test(time)) return;
    const ok = await safe(
      call(editId ? "update_lesson" : "add_lesson", {
        id: editId,
        parity,
        weekday: day,
        time,
        end: end || endTime(time),
        subject: subject.trim(),
        room: room.trim(),
        kind,
      }),
    );
    if (!ok) return;
    resetForm();
  };

  const resetForm = () => {
    setEditId(null);
    setSubject("");
    setRoom("");
    setKind("lecture");
  };

  const startEdit = (l: (typeof lessons)[number]) => {
    setEditId(l.id);
    setTime(l.time);
    setEnd(lessonEnd(l));
    setSubject(l.subject);
    setRoom(l.room);
    setKind(l.kind === "seminar" ? "seminar" : l.kind === "lecture" ? "lecture" : "");
    requestAnimationFrame(() => document.getElementById("lesson-form")?.scrollIntoView({ behavior: "smooth", block: "center" }));
  };

  const removeLesson = (id: string) => safe(call("remove_lesson", { id }));

  const pill = (on: boolean) =>
    cn(
      "rounded-full px-3 py-2 text-xs font-semibold uppercase tracking-[0.06em] transition-colors",
      on ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground",
    );

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full overflow-y-auto border-0 bg-card p-6 sm:max-w-md">
        <SheetHeader className="text-left">
          <span className="label-caps text-muted-foreground">{isHead ? "Староста" : "Студент"}</span>
          <SheetTitle className="font-head text-3xl font-bold uppercase leading-[0.95]">{me?.name}</SheetTitle>
          <SheetDescription className="sr-only">Профиль и панель старосты</SheetDescription>
        </SheetHeader>

        {isHead && (
          <section className="mt-5">
            {pwOpen ? (
              <form onSubmit={savePassword} className="flex flex-col gap-2">
                <Input
                  type="password"
                  value={pw}
                  onChange={(e) => {
                    setPw(e.target.value);
                    setPwMsg("");
                  }}
                  autoComplete="new-password"
                  placeholder="Новый пароль"
                  className="h-11 rounded-full border-0 bg-secondary px-4"
                />
                <Input
                  type="password"
                  value={pw2}
                  onChange={(e) => {
                    setPw2(e.target.value);
                    setPwMsg("");
                  }}
                  autoComplete="new-password"
                  placeholder="Повторите пароль"
                  className="h-11 rounded-full border-0 bg-secondary px-4"
                />
                <div className="flex gap-2">
                  <button type="submit" className="h-11 flex-1 rounded-full bg-primary text-xs font-semibold uppercase tracking-[0.1em] text-primary-foreground">
                    Сохранить
                  </button>
                  <button type="button" onClick={() => setPwOpen(false)} className="h-11 rounded-full bg-secondary px-4 text-xs font-semibold uppercase tracking-[0.1em]">
                    Отмена
                  </button>
                </div>
              </form>
            ) : (
              <button
                onClick={() => {
                  setPwOpen(true);
                  setPwMsg("");
                }}
                className="flex w-full items-center justify-center gap-2 rounded-full bg-secondary py-3 text-xs font-semibold uppercase tracking-[0.1em] hover:bg-accent"
              >
                <Icon name="KeyRound" size={14} />
                Сменить пароль старосты
              </button>
            )}
            {pwMsg && <p className={cn("mt-2 text-sm", pwMsg === "Пароль изменён" ? "text-primary" : "text-destructive")}>{pwMsg}</p>}
          </section>
        )}

        {isHead && (
          <section className="mt-6">
            <h3 className="font-head text-2xl font-bold uppercase">Расписание</h3>
            <p className="mt-1 text-sm text-muted-foreground">Отдельно для чётной и нечётной недели.</p>
            <div className="mt-3 flex gap-1.5">
              <button className={pill(parity === "even")} onClick={() => setParity("even")}>Чётная</button>
              <button className={pill(parity === "odd")} onClick={() => setParity("odd")}>Нечётная</button>
            </div>
            <div className="mt-2 grid grid-cols-6 gap-1.5">
              {DAYS.map(([id, label]) => (
                <button key={id} className={pill(day === id)} onClick={() => setDay(id)}>
                  {label}
                </button>
              ))}
            </div>

            <ul className="mt-4 flex flex-col gap-1.5">
              {lessons.map((l) => (
                <li key={l.id} className={cn("flex items-center gap-3 rounded-[14px] bg-secondary px-4 py-2.5", editId === l.id && "ring-2 ring-primary")}>
                  <span className="w-12 shrink-0 font-head leading-none">
                    <span className="block">{l.time}</span>
                    <span className="mt-1 block text-xs text-muted-foreground">{lessonEnd(l)}</span>
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-head uppercase">{l.subject}</span>
                    <span className="text-xs text-muted-foreground">{lessonPlace(l)}</span>
                  </span>
                  <button
                    onClick={() => startEdit(l)}
                    aria-label="Изменить пару"
                    className="grid h-8 w-8 place-items-center rounded-full text-muted-foreground hover:bg-accent hover:text-foreground"
                  >
                    <Icon name="Pencil" size={15} />
                  </button>
                  <button
                    onClick={() => {
                      if (editId === l.id) resetForm();
                      removeLesson(l.id);
                    }}
                    aria-label="Удалить пару"
                    className="grid h-8 w-8 place-items-center rounded-full text-muted-foreground hover:bg-accent hover:text-destructive"
                  >
                    <Icon name="X" size={16} />
                  </button>
                </li>
              ))}
              {lessons.length === 0 && <li className="py-3 text-sm text-muted-foreground">В этот день пар нет.</li>}
            </ul>

            <form id="lesson-form" onSubmit={addLesson} className="mt-3 grid grid-cols-2 gap-2">
              {editId && (
                <div className="col-span-2 flex items-center justify-between px-3 text-xs font-semibold uppercase tracking-[0.08em] text-primary">
                  Изменение пары
                  <button type="button" onClick={resetForm} className="text-muted-foreground hover:text-foreground">
                    Отмена
                  </button>
                </div>
              )}
              <label className="flex flex-col gap-1">
                <span className="px-3 text-xs text-muted-foreground">Начало</span>
                <Input
                  value={time}
                  onChange={(e) => {
                    setTime(e.target.value);
                    if (/^\d{1,2}:\d{2}$/.test(e.target.value)) setEnd(endTime(e.target.value));
                  }}
                  type="time"
                  className="h-11 rounded-full border-0 bg-secondary px-3"
                />
              </label>
              <label className="flex flex-col gap-1">
                <span className="px-3 text-xs text-muted-foreground">Конец</span>
                <Input
                  value={end}
                  onChange={(e) => setEnd(e.target.value)}
                  type="time"
                  className="h-11 rounded-full border-0 bg-secondary px-3"
                />
              </label>
              <Input
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Предмет"
                className="col-span-2 h-11 rounded-full border-0 bg-secondary px-4"
              />
              <div className="col-span-2 grid grid-cols-2 gap-1 rounded-full bg-secondary p-1">
                {([["lecture", "Лекция"], ["seminar", "Семинар"]] as const).map(([k, label]) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setKind(k)}
                    className={`h-9 rounded-full text-xs font-semibold uppercase tracking-[0.1em] transition-colors ${kind === k ? "bg-primary text-primary-foreground" : "hover:bg-accent"}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
              <Input
                value={room}
                onChange={(e) => setRoom(e.target.value)}
                placeholder="Аудитория, напр. 317"
                className="col-span-1 h-11 rounded-full border-0 bg-secondary px-3"
              />
              <button
                type="submit"
                disabled={!subject.trim()}
                className="h-11 rounded-full bg-primary text-xs font-semibold uppercase tracking-[0.1em] text-primary-foreground disabled:opacity-40"
              >
                {editId ? "Сохранить" : "Добавить пару"}
              </button>
            </form>
          </section>
        )}

        <div className="mt-8 flex flex-col gap-2">
          {isHead && (
            <button
              onClick={doExport}
              disabled={exporting}
              className="flex items-center justify-center gap-2 rounded-full bg-primary py-3 text-xs font-semibold uppercase tracking-[0.1em] text-primary-foreground disabled:opacity-60"
            >
              <Icon name="FileSpreadsheet" size={14} />
              {exporting ? "Готовлю файл…" : "Скачать отметки в Excel"}
            </button>
          )}
          <button
            onClick={() => {
              signOut();
              onOpenChange(false);
            }}
            className="flex items-center justify-center gap-2 rounded-full bg-secondary py-3 text-xs font-semibold uppercase tracking-[0.1em] hover:bg-accent"
          >
            <Icon name="LogOut" size={14} />
            Выйти
          </button>
        </div>
        <p className="mt-6 text-xs text-muted-foreground">
          Данные общие для всей группы. {data.students.length} человек в группе.
        </p>
      </SheetContent>
    </Sheet>
  );
}

import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Textarea } from "@/components/ui/textarea";
import Icon from "@/components/ui/icon";
import { cn } from "@/lib/utils";
import { useReadyStore } from "@/hooks/use-store";
import func2url from "../../../backend/func2url.json";

const API = (func2url as Record<string, string>).feed;

interface Comment {
  id: number;
  authorId: string;
  author: string;
  text: string;
  at: string;
}

interface Post {
  id: number;
  author: string;
  text: string;
  at: string;
  fire: number;
  mine: boolean;
  comments: Comment[];
}

const MONTHS = ["янв", "фев", "мар", "апр", "мая", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"];

function when(s: string) {
  const d = new Date(s);
  return `${d.getDate()} ${MONTHS[d.getMonth()]}, ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

function shortName(n: string) {
  const [f, i] = n.split(" ");
  return i ? `${i} ${f}` : n;
}

export default function FeedScreen({ onSeen }: { onSeen?: (lastId: number) => void }) {
  const { isHead, me } = useReadyStore();
  const [posts, setPosts] = useState<Post[] | null>(null);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState<Record<number, boolean>>({});
  const [drafts, setDrafts] = useState<Record<number, string>>({});
  const loading = useRef(false);

  const api = useCallback(async (action: string, payload: Record<string, unknown> = {}) => {
    const res = await fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Auth-Token": localStorage.getItem("moya-gruppa-token") ?? "" },
      body: JSON.stringify({ action, ...payload }),
    }).catch(() => null);
    if (!res) {
      toast.error("Нет связи. Проверьте интернет.");
      return false;
    }
    const json = await res.json();
    if (!res.ok) {
      toast.error(json.error || "Не получилось");
      return false;
    }
    setPosts(json.posts);
    onSeen?.(json.posts.reduce((m: number, p: Post) => Math.max(m, p.id), 0));
    return true;
  }, [onSeen]);

  const load = useCallback(async () => {
    if (loading.current) return;
    loading.current = true;
    await api("list");
    loading.current = false;
  }, [api]);

  useEffect(() => {
    load();
    const t = setInterval(() => document.visibilityState === "visible" && load(), 30_000);
    const onVisible = () => document.visibilityState === "visible" && load();
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      clearInterval(t);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [load]);

  const send = async () => {
    if (!text.trim()) return;
    setBusy(true);
    if (await api("post", { text })) setText("");
    setBusy(false);
  };

  const comment = async (postId: number) => {
    const t = (drafts[postId] ?? "").trim();
    if (!t) return;
    if (await api("comment", { postId, text: t })) setDrafts((d) => ({ ...d, [postId]: "" }));
  };

  const react = (postId: number) => {
    setPosts((ps) => ps?.map((p) => (p.id === postId ? { ...p, mine: !p.mine, fire: p.fire + (p.mine ? -1 : 1) } : p)) ?? ps);
    api("react", { postId });
  };

  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col gap-5 animate-rise">
      <div className="flex items-end justify-between gap-3">
        <h1 className="font-head text-[3.2rem] sm:text-[4.2rem] lg:text-[84px] font-bold uppercase leading-[0.95] tracking-[-0.01em]">
          Важно
          <br />
          <span className="text-primary">для всех</span>
        </h1>
        <button
          type="button"
          onClick={load}
          aria-label="Обновить"
          className="mb-2 grid h-11 w-11 shrink-0 place-items-center rounded-full bg-secondary hover:bg-accent"
        >
          <Icon name="RefreshCw" size={18} />
        </button>
      </div>

      {isHead ? (
        <div className="rounded-[18px] bg-card p-4">
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Сообщение для всей группы"
            className="min-h-[90px] rounded-[14px] border-0 bg-secondary text-base"
          />
          <div className="mt-3 flex justify-end">
            <button
              type="button"
              onClick={send}
              disabled={busy || !text.trim()}
              className="flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-xs font-semibold uppercase tracking-[0.1em] text-primary-foreground disabled:opacity-50"
            >
              <Icon name="Send" size={14} />
              Отправить всем
            </button>
          </div>
        </div>
      ) : (
        <p className="text-muted-foreground">Здесь староста публикует важное. Ставь огонёк и пиши комментарии.</p>
      )}

      {posts === null && <div className="py-10 text-center text-muted-foreground animate-pulse">Загружаю…</div>}
      {posts?.length === 0 && <div className="rounded-[18px] bg-card py-10 text-center text-muted-foreground">Пока сообщений нет</div>}

      <ul className="flex flex-col gap-4">
        {posts?.map((p) => {
          const expanded = open[p.id];
          return (
            <li key={p.id} className="rounded-[18px] bg-card p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-primary">{shortName(p.author)} · староста</div>
                  <div className="text-xs text-muted-foreground">{when(p.at)}</div>
                </div>
                {isHead && (
                  <button
                    type="button"
                    aria-label="Удалить сообщение"
                    onClick={() => window.confirm("Удалить сообщение для всех?") && api("hide_post", { id: p.id })}
                    className="text-muted-foreground hover:text-destructive"
                  >
                    <Icon name="Trash2" size={16} />
                  </button>
                )}
              </div>
              <p className="mt-3 whitespace-pre-wrap break-words text-[1.05rem] leading-relaxed">{p.text}</p>

              <div className="mt-4 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => react(p.id)}
                  className={cn(
                    "flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-semibold transition-colors",
                    p.mine ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-accent",
                  )}
                >
                  <Icon name="Flame" size={16} />
                  {p.fire > 0 && p.fire}
                </button>
                <button
                  type="button"
                  onClick={() => setOpen((o) => ({ ...o, [p.id]: !o[p.id] }))}
                  className="flex items-center gap-1.5 rounded-full bg-secondary px-4 py-2 text-sm font-semibold hover:bg-accent"
                >
                  <Icon name="MessageCircle" size={16} />
                  {p.comments.length > 0 ? p.comments.length : "Комментировать"}
                </button>
              </div>

              {expanded && (
                <div className="mt-4 flex flex-col gap-2 border-t border-white/10 pt-4">
                  {p.comments.map((c) => (
                    <div key={c.id} className="rounded-[14px] bg-white/[0.06] px-4 py-3">
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate text-sm font-semibold">{shortName(c.author)}</span>
                        <span className="flex shrink-0 items-center gap-2 text-xs text-muted-foreground">
                          {when(c.at)}
                          {(isHead || c.authorId === me?.id) && (
                            <button
                              type="button"
                              aria-label="Удалить комментарий"
                              onClick={() => api("hide_comment", { id: c.id })}
                              className="hover:text-destructive"
                            >
                              <Icon name="X" size={14} />
                            </button>
                          )}
                        </span>
                      </div>
                      <p className="mt-1 whitespace-pre-wrap break-words text-sm">{c.text}</p>
                    </div>
                  ))}
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      comment(p.id);
                    }}
                    className="mt-1 flex gap-2"
                  >
                    <input
                      value={drafts[p.id] ?? ""}
                      onChange={(e) => setDrafts((d) => ({ ...d, [p.id]: e.target.value }))}
                      placeholder="Написать комментарий"
                      maxLength={1000}
                      className="h-11 min-w-0 flex-1 rounded-full bg-secondary px-4 text-sm outline-none"
                    />
                    <button
                      type="submit"
                      aria-label="Отправить"
                      className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground"
                    >
                      <Icon name="Send" size={16} />
                    </button>
                  </form>
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

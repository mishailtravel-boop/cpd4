import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import Icon from "@/components/ui/icon";
import StatusDot, { STATUS_LABEL } from "@/components/app/StatusDot";
import { safe, useReadyStore } from "@/hooks/use-store";
import { cn } from "@/lib/utils";
import { dayTitle, iso, lessonEnd, lessonsFor, prettyDate, targetDate, type VoteStatus } from "@/lib/schedule";

const OPTIONS: { id: VoteStatus; title: string; hint: string; icon: string }[] = [
  { id: "all", title: "Буду на всех парах", hint: "Отмечу весь день", icon: "CheckCheck" },
  { id: "some", title: "Буду на определённых", hint: "Выберу пары галочками", icon: "ListChecks" },
  { id: "none", title: "Отсутствую", hint: "Пропущу весь день", icon: "X" },
];

export default function AttendanceScreen() {
  const { data, now, call, me, isHead } = useReadyStore();
  const day = targetDate(now);
  const key = iso(day);
  const lessons = lessonsFor(data, day);
  const myVote = me ? data.attendance[key]?.[me.id] : undefined;
  const [picker, setPicker] = useState(false);
  const [picked, setPicked] = useState<string[]>([]);
  const [filter, setFilter] = useState<VoteStatus | "pending" | null>(null);

  useEffect(() => {
    if (picker) setPicked(myVote?.status === "some" ? myVote.lessons : []);
  }, [picker, myVote]);

  const vote = (status: VoteStatus, ids: string[] = []) => {
    if (!me) return;
    safe(call("vote", { day: key, status, lessons: ids }));
  };

  const confirmSome = () => {
    if (picked.length === 0) return;
    if (picked.length === lessons.length) vote("all");
    else vote("some", picked);
    setPicker(false);
  };

  const votes = data.attendance[key] ?? {};
  const counts = {
    all: data.students.filter((s) => votes[s.id]?.status === "all").length,
    some: data.students.filter((s) => votes[s.id]?.status === "some").length,
    none: data.students.filter((s) => votes[s.id]?.status === "none").length,
    pending: data.students.filter((s) => !votes[s.id]).length,
  };
  const visible = data.students.filter((s) => {
    if (!filter) return true;
    if (filter === "pending") return !votes[s.id];
    return votes[s.id]?.status === filter;
  });

  return (
    <div className="grid gap-6 grid-cols-1 [&>*]:min-w-0 md:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)] md:gap-10">
      <div className="flex flex-col gap-5 animate-rise">
        <div>
          <span className="label-caps text-muted-foreground">
            {dayTitle(day, now)} · {prettyDate(day)} · {lessons.length} пар
          </span>
          <h1 className="mt-2 font-head text-[3.2rem] sm:text-[4.2rem] lg:text-[84px] font-bold uppercase leading-[0.95] tracking-[-0.01em]">
            Ты
            <br />
            придёшь?
          </h1>
        </div>

        {lessons.length === 0 ? (
          <p className="text-muted-foreground">В этот день пар нет — отмечаться не нужно.</p>
        ) : (
          <div className="flex flex-col gap-2.5">
            {OPTIONS.map((o) => {
              const on = myVote?.status === o.id;
              return (
                <button
                  key={o.id}
                  type="button"
                  onClick={() => (o.id === "some" ? setPicker(true) : vote(o.id))}
                  className={cn(
                    "flex items-center gap-4 rounded-full px-5 py-4 text-left transition-all active:scale-[0.98]",
                    on && o.id === "all" && "bg-primary text-primary-foreground",
                    on && o.id === "some" && "bg-warning text-warning-foreground",
                    on && o.id === "none" && "bg-destructive text-destructive-foreground",
                    !on && "bg-secondary hover:bg-accent",
                  )}
                >
                  <span
                    className={cn(
                      "grid h-10 w-10 shrink-0 place-items-center rounded-full",
                      on ? "bg-black/15" : "bg-white/[0.08]",
                    )}
                  >
                    <Icon name={o.icon} size={18} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-head text-xl font-semibold uppercase leading-tight">{o.title}</span>
                    <span className={cn("text-sm", on ? "opacity-75" : "text-muted-foreground")}>
                      {on && o.id === "some" && myVote
                        ? `Выбрано: ${myVote.lessons.length} из ${lessons.length}`
                        : o.hint}
                    </span>
                  </span>
                  {on && <Icon name="Check" size={20} />}
                </button>
              );
            })}
          </div>
        )}
        {myVote && (
          <p className="text-sm text-muted-foreground">Ответ сохранён. Можно поменять до начала пар.</p>
        )}
      </div>

      <div className="bg-card p-4 sm:p-[26px]">
        {isHead ? (
          <>
            <div className="flex items-baseline justify-between">
              <h2 className="font-head text-2xl font-bold uppercase">Отметки группы</h2>
              <span className="text-sm text-muted-foreground">
                {data.students.length - counts.pending}/{data.students.length}
              </span>
            </div>
            <div className="mt-4 grid grid-cols-4 gap-1.5">
              {(
                [
                  ["all", "Все", "bg-primary text-primary-foreground"],
                  ["some", "Часть", "bg-warning text-warning-foreground"],
                  ["none", "Нет", "bg-destructive text-destructive-foreground"],
                  ["pending", "Ждём", "bg-secondary text-foreground"],
                ] as const
              ).map(([id, label, cls]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setFilter(filter === id ? null : id)}
                  className={cn(
                    "rounded-[14px] px-2 py-2.5 text-center transition-all",
                    cls,
                    filter && filter !== id && "opacity-40",
                  )}
                >
                  <b className="block font-head text-2xl leading-none">{counts[id]}</b>
                  <small className="text-[0.65rem] font-semibold uppercase tracking-[0.08em]">{label}</small>
                </button>
              ))}
            </div>
            <ul className="mt-4 flex flex-col gap-1.5">
              {visible.map((s) => {
                const v = votes[s.id];
                return (
                  <li key={s.id} className="rounded-[14px] bg-white/[0.05] px-4 py-3">
                    <div className="flex items-center gap-3">
                      <StatusDot status={v?.status ?? null} />
                      <span className="min-w-0 flex-1 truncate">{s.name}</span>
                      <span className="shrink-0 text-xs text-muted-foreground">
                        {v
                          ? v.status === "some"
                            ? `${lessons.filter((l) => v.lessons.includes(l.id)).length}/${lessons.length}`
                            : STATUS_LABEL[v.status]
                          : "не отметился"}
                      </span>
                    </div>
                    {v?.status === "some" && (
                      <ul className="mt-2 flex flex-col gap-1 pl-6">
                        {lessons.map((l) => {
                          const here = v.lessons.includes(l.id);
                          return (
                            <li key={l.id} className="flex items-center gap-2 text-sm">
                              <Icon
                                name={here ? "CircleCheck" : "CircleX"}
                                size={16}
                                className={cn("shrink-0", here ? "text-primary" : "text-destructive")}
                              />
                              <span className="w-[86px] shrink-0 font-head text-muted-foreground">{l.time}–{lessonEnd(l)}</span>
                              <span className={cn("min-w-0 flex-1 truncate", !here && "text-muted-foreground line-through")}>
                                {l.subject}
                              </span>
                              <span className={cn("shrink-0 text-xs", here ? "text-primary" : "text-destructive")}>
                                {here ? "есть" : "нет"}
                              </span>
                            </li>
                          );
                        })}
                      </ul>
                    )}
                  </li>
                );
              })}
              {visible.length === 0 && <li className="py-6 text-center text-muted-foreground">Никого</li>}
            </ul>
          </>
        ) : (
          <div className="flex h-full flex-col justify-center gap-3">
            <h2 className="font-head text-2xl font-bold uppercase">Пары дня</h2>
            {lessons.map((l) => {
              const going =
                myVote?.status === "all" || (myVote?.status === "some" && myVote.lessons.includes(l.id));
              return (
                <div key={l.id} className="flex items-center gap-3 rounded-[18px] bg-white/[0.08] px-4 py-3.5">
                  <span className="w-14 shrink-0 font-head leading-none">
                    <span className="block text-lg">{l.time}</span>
                    <span className="mt-1 block text-sm text-muted-foreground">{lessonEnd(l)}</span>
                  </span>
                  <span className="min-w-0 flex-1 truncate font-head text-lg uppercase">{l.subject}</span>
                  {myVote && (
                    <Icon
                      name={going ? "CircleCheck" : "CircleMinus"}
                      size={20}
                      className={going ? "text-primary" : "text-destructive"}
                    />
                  )}
                </div>
              );
            })}
            <p className="mt-2 text-sm text-muted-foreground">Каждая пропущенная пара — это 2 часа пропуска.</p>
          </div>
        )}
      </div>

      <Dialog open={picker} onOpenChange={setPicker}>
        <DialogContent className="w-[calc(100%-1.5rem)] max-w-md rounded-[18px] border-0 bg-card p-6">
          <DialogHeader className="text-left">
            <DialogTitle className="font-head text-3xl font-bold uppercase leading-none">На какие пары придёшь?</DialogTitle>
            <DialogDescription>Отметь хотя бы одну пару — это обязательно.</DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-2">
            {lessons.map((l) => {
              const checked = picked.includes(l.id);
              return (
                <label
                  key={l.id}
                  className={cn(
                    "flex cursor-pointer items-center gap-3 rounded-[14px] px-4 py-3.5 transition-colors",
                    checked ? "bg-primary/15" : "bg-secondary",
                  )}
                >
                  <span className="w-12 shrink-0 font-head leading-none text-muted-foreground">
                    <span className="block text-base">{l.time}</span>
                    <span className="mt-1 block text-sm opacity-70">{lessonEnd(l)}</span>
                  </span>
                  <span className="min-w-0 flex-1 truncate font-head text-lg uppercase">{l.subject}</span>
                  <Checkbox
                    checked={checked}
                    onCheckedChange={(v) =>
                      setPicked((p) => (v ? [...p, l.id] : p.filter((x) => x !== l.id)))
                    }
                    className="h-6 w-6 rounded-md border-primary data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
                  />
                </label>
              );
            })}
          </div>
          <button
            type="button"
            disabled={picked.length === 0}
            onClick={confirmSome}
            className="mt-2 w-full rounded-full bg-primary py-3.5 text-sm font-semibold uppercase tracking-[0.1em] text-primary-foreground transition-opacity disabled:opacity-35"
          >
            {picked.length === 0 ? "Выбери пары" : `Готово · ${picked.length}`}
          </button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
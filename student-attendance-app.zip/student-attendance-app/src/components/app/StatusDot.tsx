import { cn } from "@/lib/utils";
import type { VoteStatus } from "@/lib/schedule";

export const STATUS_LABEL: Record<VoteStatus, string> = {
  all: "На всех парах",
  some: "На части пар",
  none: "Отсутствует",
};

export default function StatusDot({ status, className }: { status: VoteStatus | null; className?: string }) {
  return (
    <span
      aria-label={status ? STATUS_LABEL[status] : "Не отметился"}
      className={cn(
        "inline-block h-3.5 w-3.5 shrink-0 rounded-full",
        status === "all" && "bg-primary",
        status === "some" && "bg-warning",
        status === "none" && "bg-destructive",
        !status && "border-2 border-dashed border-muted-foreground/60",
        className,
      )}
    />
  );
}

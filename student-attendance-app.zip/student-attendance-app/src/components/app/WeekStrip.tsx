import { cn } from "@/lib/utils";
import Icon from "@/components/ui/icon";
import { addDays, iso, MONTHS_SHORT, WEEKDAYS_SHORT } from "@/lib/schedule";

interface Props {
  monday: Date;
  selected: Date;
  today: Date;
  onSelect: (d: Date) => void;
  onShift: (weeks: number) => void;
}

export default function WeekStrip({ monday, selected, today, onSelect, onShift }: Props) {
  const days = Array.from({ length: 7 }, (_, i) => addDays(monday, i));
  const m1 = MONTHS_SHORT[days[0].getMonth()];
  const m2 = MONTHS_SHORT[days[6].getMonth()];
  const selIso = iso(selected);
  const todayIso = iso(today);

  return (
    <div className="grid grid-cols-[auto_auto_repeat(7,minmax(0,1fr))_auto] items-stretch gap-1.5 sm:gap-2.5">
      <div className="self-center pr-1 sm:pr-2.5 font-head text-base sm:text-[1.6rem] font-bold uppercase leading-[0.95]">
        {m1}
        {m1 !== m2 && (
          <>
            <br />
            {m2}
          </>
        )}
      </div>
      <ArrowButton dir={-1} onClick={() => onShift(-1)} />
      {days.map((d) => {
        const on = iso(d) === selIso;
        const isToday = iso(d) === todayIso;
        const weekend = d.getDay() === 0 || d.getDay() === 6;
        return (
          <button
            key={iso(d)}
            type="button"
            onClick={() => onSelect(d)}
            className={cn(
              "relative rounded-full py-2 sm:py-2.5 text-center transition-colors",
              on ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-accent",
            )}
          >
            <small
              className={cn(
                "block text-[0.62rem] sm:text-[0.75rem] font-semibold uppercase tracking-[0.08em]",
                on ? "text-primary-foreground" : "text-muted-foreground",
                weekend && !on && "opacity-60",
              )}
            >
              {WEEKDAYS_SHORT[d.getDay()]}
            </small>
            <b className="block font-head text-xl sm:text-[1.8rem] leading-none">
              {String(d.getDate()).padStart(2, "0")}
            </b>
            {isToday && !on && (
              <span className="absolute bottom-1 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-primary" />
            )}
          </button>
        );
      })}
      <ArrowButton dir={1} onClick={() => onShift(1)} />
    </div>
  );
}

function ArrowButton({ dir, onClick }: { dir: 1 | -1; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={dir > 0 ? "Следующая неделя" : "Предыдущая неделя"}
      title={dir > 0 ? "Следующая неделя" : "Предыдущая неделя"}
      className="grid w-7 sm:w-11 place-items-center rounded-full text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
    >
      <Icon name={dir > 0 ? "ChevronRight" : "ChevronLeft"} size={22} />
    </button>
  );
}

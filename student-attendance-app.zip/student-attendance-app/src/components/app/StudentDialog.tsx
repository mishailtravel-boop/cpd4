import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import StatusDot from "@/components/app/StatusDot";
import Icon from "@/components/ui/icon";
import { safe, useReadyStore } from "@/hooks/use-store";
import { fromIso, hoursWord, lessonsFor, prettyDate, totalMissedHours, WEEKDAYS_SHORT, type Student } from "@/lib/schedule";

interface Props {
  student: Student | null;
  onClose: () => void;
}

export default function StudentDialog({ student, onClose }: Props) {
  const { data, call, isHead, me } = useReadyStore();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");

  useEffect(() => {
    setEditing(false);
  }, [student?.id]);

  const saveHours = () => {
    if (!student) return;
    const n = Math.max(0, Math.round(Number(draft)));
    if (!Number.isFinite(n)) return;
    const { auto } = totalMissedHours(data, student.id);
    safe(call("set_hours_adjust", { id: student.id, adjust: n - auto })).then((ok) => ok && setEditing(false));
  };

  const resetHours = () => {
    if (!student) return;
    safe(call("set_hours_adjust", { id: student.id, adjust: 0 })).then((ok) => ok && setEditing(false));
  };

  const content = (() => {
    if (!student) return null;
    const { hours, lessons, adjust, auto } = totalMissedHours(data, student.id);
    const bySubject: Record<string, number> = {};
    const history: { day: string; status: "all" | "some" | "none"; missed: string[] }[] = [];
    Object.keys(data.attendance)
      .sort((a, b) => b.localeCompare(a))
      .forEach((day) => {
        const v = data.attendance[day][student.id];
        if (!v) return;
        const ls = lessonsFor(data, fromIso(day));
        const missed = ls.filter((l) => v.status === "none" || (v.status === "some" && !v.lessons.includes(l.id)));
        missed.forEach((l) => (bySubject[l.subject] = (bySubject[l.subject] ?? 0) + 2));
        history.push({ day, status: v.status, missed: missed.map((m) => m.subject) });
      });
    const subjects = Object.entries(bySubject).sort((a, b) => b[1] - a[1]);
    return { hours, lessons, adjust, auto, subjects, history };
  })();

  const remove = () => {
    if (!student) return;
    safe(call("remove_student", { id: student.id })).then((ok) => ok && onClose());
  };

  return (
    <Dialog open={!!student} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90dvh] w-[calc(100vw-1.5rem)] max-w-lg overflow-y-auto overflow-x-hidden rounded-[18px] border-0 bg-card p-5 sm:p-6 [&>*]:min-w-0">
        {student && content && (
          <>
            <DialogHeader className="text-left">
              <span className="label-caps text-muted-foreground">
                {student.role === "head" ? "Староста" : "Студент"}
              </span>
              <DialogTitle className="break-words pr-6 font-head text-2xl sm:text-3xl font-bold uppercase leading-[0.95]">{student.name}</DialogTitle>
              <DialogDescription className="sr-only">Пропуски студента</DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-2 gap-2">
              <div className="min-w-0 rounded-[18px] bg-primary p-4 text-primary-foreground">
                <b className="block font-head text-5xl leading-none">{content.hours}</b>
                <small className="block text-[0.65rem] font-semibold uppercase tracking-[0.06em]">{hoursWord(content.hours)} пропусков</small>
              </div>
              <div className="min-w-0 rounded-[18px] bg-secondary p-4">
                <b className="block font-head text-5xl leading-none">{content.lessons}</b>
                <small className="block text-[0.65rem] font-semibold uppercase tracking-[0.06em] text-muted-foreground">пар пропущено</small>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              1 пропущенная пара = 2 часа.
              {content.adjust !== 0 && ` По отметкам ${content.auto} ч, исправлено старостой.`}
            </p>

            {isHead && (
              editing ? (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    saveHours();
                  }}
                  className="flex items-center gap-2"
                >
                  <input
                    type="number"
                    min={0}
                    inputMode="numeric"
                    autoFocus
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    className="h-11 w-0 min-w-0 flex-1 rounded-full bg-secondary px-4 font-head text-lg outline-none focus:ring-2 focus:ring-ring"
                  />
                  <button type="submit" className="h-11 shrink-0 rounded-full bg-primary px-4 text-xs font-semibold uppercase tracking-[0.08em] text-primary-foreground">
                    Сохранить
                  </button>
                  <button type="button" onClick={() => setEditing(false)} aria-label="Отмена" className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-secondary">
                    <Icon name="X" size={16} />
                  </button>
                </form>
              ) : (
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setDraft(String(content.hours));
                      setEditing(true);
                    }}
                    className="flex items-center gap-2 rounded-full bg-secondary px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.08em] hover:bg-accent"
                  >
                    <Icon name="Pencil" size={14} />
                    Изменить часы
                  </button>
                  {content.adjust !== 0 && (
                    <button type="button" onClick={resetHours} className="rounded-full px-3 py-2.5 text-xs text-muted-foreground underline-offset-4 hover:underline">
                      Вернуть по отметкам
                    </button>
                  )}
                </div>
              )
            )}

            {content.subjects.length > 0 && (
              <div>
                <h4 className="label-caps mb-2 text-muted-foreground">По предметам</h4>
                <ul className="flex flex-col gap-1.5">
                  {content.subjects.map(([name, h]) => (
                    <li key={name} className="flex items-center justify-between gap-3 rounded-[14px] bg-secondary px-4 py-2.5">
                      <span className="min-w-0 truncate font-head uppercase">{name}</span>
                      <span className="shrink-0 font-head text-lg">{h} ч</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div>
              <h4 className="label-caps mb-2 text-muted-foreground">История отметок</h4>
              {content.history.length === 0 ? (
                <p className="text-sm text-muted-foreground">Пока ни одной отметки.</p>
              ) : (
                <ul className="flex flex-col gap-1.5">
                  {content.history.map((h) => {
                    const d = fromIso(h.day);
                    return (
                      <li key={h.day} className="flex items-start gap-3 rounded-[14px] bg-white/[0.05] px-4 py-2.5">
                        <span className="pt-1.5"><StatusDot status={h.status} /></span>
                        <span className="min-w-0 flex-1">
                          <span className="block text-sm">
                            {WEEKDAYS_SHORT[d.getDay()]}, {prettyDate(d)}
                          </span>
                          <span className="block break-words text-xs text-muted-foreground">
                            {h.missed.length ? `Пропустил: ${h.missed.join(", ")}` : "Был на всех парах"}
                          </span>
                        </span>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>

            {isHead && student.id !== me?.id && (
              <button
                onClick={remove}
                className="flex items-center justify-center gap-2 rounded-full bg-secondary py-3 text-xs font-semibold uppercase tracking-[0.1em] text-destructive hover:bg-accent"
              >
                <Icon name="Trash2" size={14} />
                Убрать из группы
              </button>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

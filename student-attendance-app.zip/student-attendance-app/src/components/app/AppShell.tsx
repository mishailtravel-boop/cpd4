import { useEffect, useState } from "react";
import AppHeader from "@/components/app/AppHeader";
import WeekStrip from "@/components/app/WeekStrip";
import TabBar, { type Tab } from "@/components/app/TabBar";
import HomeScreen from "@/components/app/HomeScreen";
import AttendanceScreen from "@/components/app/AttendanceScreen";
import GroupScreen from "@/components/app/GroupScreen";
import FeedScreen from "@/components/app/FeedScreen";
import Onboarding from "@/components/app/Onboarding";
import ProfileSheet from "@/components/app/ProfileSheet";
import { useStore, useReadyStore } from "@/hooks/use-store";
import { useFeedBadge } from "@/hooks/use-feed-badge";
import { addDays, iso, mondayOf, targetDate, weekParity } from "@/lib/schedule";

function Splash() {
  return (
    <div className="grid min-h-[100dvh] place-items-center">
      <div className="font-head text-4xl font-bold uppercase animate-pulse">Моя группа</div>
    </div>
  );
}

function MainApp() {
  const { now, me } = useReadyStore();
  const [tab, setTab] = useState<Tab>("home");
  const [selected, setSelected] = useState<Date>(() => targetDate(now));
  const [profile, setProfile] = useState(false);
  const { unread, markSeen } = useFeedBadge(tab === "feed");
  const target = iso(targetDate(now));

  // В 18:00 главная сама переключается на следующий учебный день
  useEffect(() => {
    setSelected(targetDate(now));
  }, [target]); // eslint-disable-line react-hooks/exhaustive-deps

  const parity = weekParity(selected);

  const initials = (me?.name ?? "")
    .split(" ")
    .slice(0, 2)
    .map((w) => w[0])
    .join("");

  const showWeek = tab === "home";

  return (
    <div className="mx-auto grid min-h-[100dvh] w-full max-w-[1400px] grid-cols-[minmax(0,1fr)] grid-rows-[auto_auto_1fr_auto] gap-[18px] px-3 pt-4 sm:px-8 sm:pt-5 lg:px-12">
      <AppHeader
        parity={parity}
        initials={initials}
        onProfile={() => setProfile(true)}
      />
      {showWeek ? (
        <WeekStrip
          monday={mondayOf(selected)}
          selected={selected}
          today={now}
          onSelect={setSelected}
          onShift={(w) => setSelected((d) => addDays(d, w * 7))}
        />
      ) : (
        <div />
      )}
      <main key={tab} className="min-h-0 pb-2">
        {tab === "home" && <HomeScreen date={selected} onAttend={() => setTab("attendance")} />}
        {tab === "attendance" && <AttendanceScreen />}
        {tab === "feed" && <FeedScreen onSeen={markSeen} />}
        {tab === "group" && <GroupScreen />}
      </main>
      <div className="sticky bottom-0 -mx-3 bg-background/90 px-3 pb-4 pt-2 backdrop-blur sm:-mx-8 sm:px-8 sm:pb-5 lg:-mx-12 lg:px-12">
        <TabBar tab={tab} onTab={setTab} badges={{ feed: unread }} />
      </div>
      <ProfileSheet open={profile} onOpenChange={setProfile} />
    </div>
  );
}

export default function AppShell() {
  const { data, loaded, failed, now, refresh } = useStore();
  if (!loaded) return <Splash />;
  if (!data || !now)
    return (
      <div className="grid min-h-[100dvh] place-items-center px-6 text-center">
        <div>
          <div className="font-head text-4xl font-bold uppercase">Нет связи</div>
          <p className="mt-2 text-muted-foreground">{failed ? "Не удалось загрузить данные группы." : ""}</p>
          <button
            type="button"
            onClick={() => refresh()}
            className="mt-5 rounded-full bg-primary px-6 py-3 text-xs font-semibold uppercase tracking-[0.1em] text-primary-foreground"
          >
            Повторить
          </button>
        </div>
      </div>
    );
  if (!data.meId || !data.students.some((s) => s.id === data.meId)) return <Onboarding />;
  return <MainApp />;
}

import { useState } from "react";
import { Input } from "@/components/ui/input";
import Icon from "@/components/ui/icon";
import StatusDot from "@/components/app/StatusDot";
import StudentDialog from "@/components/app/StudentDialog";
import { safe, useReadyStore } from "@/hooks/use-store";
import { iso, targetDate, totalMissedHours, type Student } from "@/lib/schedule";

export default function GroupScreen() {
  const { data, now, call, isHead, me } = useReadyStore();
  const [query, setQuery] = useState("");
  const [newName, setNewName] = useState("");
  const [error, setError] = useState("");
  const [open, setOpen] = useState<Student | null>(null);
  const key = iso(targetDate(now));
  const votes = data.attendance[key] ?? {};

  const list = [...data.students]
    .sort((a, b) => a.name.localeCompare(b.name, "ru"))
    .filter((s) => s.name.toLowerCase().includes(query.trim().toLowerCase()));

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newName.trim().replace(/\s+/g, " ");
    if (clean.split(" ").length < 2) return setError("Фамилия и имя — минимум");
    if (data.students.some((s) => s.name.toLowerCase() === clean.toLowerCase())) return setError("Такой уже есть");
    const ok = await safe(call("add_student", { name: clean }));
    if (!ok) return;
    setNewName("");
    setError("");
  };

  return (
    <div className="grid gap-6 grid-cols-1 [&>*]:min-w-0 md:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)] md:gap-10">
      <div className="flex flex-col gap-5 animate-rise">
        <h1 className="font-head text-[3.2rem] sm:text-[4.2rem] lg:text-[84px] font-bold uppercase leading-[0.95] tracking-[-0.01em]">
          Группа
          <br />
          <span className="text-primary">{data.students.length}</span> чел.
        </h1>
        <p className="max-w-[32ch] text-[1.1rem]">Жми на человека — увидишь его часы пропусков и историю отметок.</p>

        {isHead && (
          <form onSubmit={add} className="rounded-[18px] bg-card p-5">
            <span className="label-caps text-muted-foreground">Добавить студента</span>
            <div className="mt-3 flex gap-2">
              <Input
                value={newName}
                onChange={(e) => {
                  setNewName(e.target.value);
                  setError("");
                }}
                placeholder="Фамилия Имя Отчество"
                className="h-12 rounded-full border-0 bg-secondary px-5"
              />
              <button
                type="submit"
                aria-label="Добавить"
                className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground"
              >
                <Icon name="Plus" size={20} />
              </button>
            </div>
            {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
          </form>
        )}

        <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5"><StatusDot status="all" /> все пары</span>
          <span className="flex items-center gap-1.5"><StatusDot status="some" /> часть</span>
          <span className="flex items-center gap-1.5"><StatusDot status="none" /> отсутствует</span>
          <span className="flex items-center gap-1.5"><StatusDot status={null} /> не отметился</span>
        </div>
      </div>

      <div className="bg-card p-4 sm:p-[26px]">
        <div className="relative">
          <Icon name="Search" size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Поиск по группе"
            className="h-12 rounded-full border-0 bg-secondary pl-11"
          />
        </div>
        <ul className="mt-3 flex flex-col gap-1.5">
          {list.map((s, i) => {
            const { hours } = totalMissedHours(data, s.id);
            return (
              <li key={s.id}>
                <button
                  type="button"
                  onClick={() => setOpen(s)}
                  className="flex w-full items-center gap-3 rounded-[18px] bg-white/[0.06] px-4 py-3.5 text-left transition-colors hover:bg-white/[0.1]"
                >
                  <span className="w-6 font-head text-sm text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>
                  {isHead && <StatusDot status={votes[s.id]?.status ?? null} />}
                  <span className="min-w-0 flex-1">
                    <span className="block truncate">{s.name}</span>
                    {(s.role === "head" || s.id === me?.id) && (
                      <span className="text-xs text-primary">
                        {[s.role === "head" ? "староста" : "", s.id === me?.id ? "это ты" : ""].filter(Boolean).join(" · ")}
                      </span>
                    )}
                  </span>
                  <span className="shrink-0 rounded-full border-[1.5px] border-current px-2.5 py-1 text-[0.7rem] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
                    {hours} ч
                  </span>
                </button>
              </li>
            );
          })}
          {list.length === 0 && <li className="py-8 text-center text-muted-foreground">Никого не нашли</li>}
        </ul>
      </div>

      <StudentDialog student={open} onClose={() => setOpen(null)} />
    </div>
  );
}

import { cn } from "@/lib/utils";
import { lessonEnd, lessonPlace, type Lesson } from "@/lib/schedule";

interface Props {
  lesson: Lesson;
  state: "now" | "next" | "past" | "idle";
  hasHomework: boolean;
  onOpen: () => void;
  index: number;
  highlight?: boolean;
}

export default function LessonCard({ lesson, state, hasHomework, onOpen, index, highlight }: Props) {
  const now = highlight ?? state === "now";
  const note = state === "now" ? " · идёт" : state === "next" ? " · следующая" : "";
  return (
    <button
      type="button"
      onClick={onOpen}
      style={{ animationDelay: `${index * 70}ms` }}
      className={cn(
        "grid w-full animate-rise grid-cols-[52px_minmax(0,1fr)_auto] sm:grid-cols-[64px_minmax(0,1fr)_auto] items-center gap-3 sm:gap-3.5 rounded-[18px] px-4 py-4 sm:px-5 text-left transition-transform active:scale-[0.98]",
        now ? "bg-primary text-primary-foreground" : "bg-white/[0.08] text-foreground hover:bg-white/[0.12]",
        state === "past" && "opacity-55",
      )}
    >
      <span className="font-head leading-none">
        <span className="block text-lg sm:text-[1.3rem]">{lesson.time}</span>
        <span className="mt-1 block text-[0.85rem] sm:text-base opacity-60">{lessonEnd(lesson)}</span>
      </span>
      <div className="min-w-0">
        <h3 className="truncate font-head text-lg sm:text-[1.35rem] font-semibold uppercase leading-tight">
          {lesson.subject}
        </h3>
        <small className="text-[0.8rem] opacity-70">
          {lessonPlace(lesson)}
          {note}
        </small>
      </div>
      <i className="rounded-full border-[1.5px] border-current px-2.5 py-1 text-[0.7rem] font-semibold not-italic uppercase tracking-[0.08em]">
        {hasHomework ? "ДЗ" : "Нет"}
      </i>
    </button>
  );
}
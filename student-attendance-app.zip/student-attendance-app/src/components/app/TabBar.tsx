import { cn } from "@/lib/utils";
import Icon from "@/components/ui/icon";

export type Tab = "home" | "attendance" | "feed" | "group";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "home", label: "Главная", icon: "House" },
  { id: "attendance", label: "Посещаемость", icon: "CircleCheck" },
  { id: "feed", label: "Важно для всех", icon: "Megaphone" },
  { id: "group", label: "Группа", icon: "Users" },
];

export default function TabBar({ tab, onTab, badges = {} }: { tab: Tab; onTab: (t: Tab) => void; badges?: Partial<Record<Tab, boolean>> }) {
  return (
    <nav className="grid grid-cols-2 gap-1.5 sm:grid-cols-4 sm:gap-2.5">
      {TABS.map((t) => (
        <button
          key={t.id}
          type="button"
          onClick={() => onTab(t.id)}
          className={cn(
            "relative flex items-center justify-center gap-2 rounded-full px-2 py-3 sm:py-3.5 text-[0.68rem] sm:text-[0.85rem] font-semibold uppercase tracking-[0.1em] transition-colors",
            tab === t.id ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground hover:bg-accent",
          )}
        >
          <Icon name={t.icon} size={16} className="hidden sm:block" />
          <span className="truncate">{t.label}</span>
          {badges[t.id] && tab !== t.id && (
            <span aria-label="Есть новое" className="absolute right-3 top-1.5 h-2.5 w-2.5 rounded-full bg-primary ring-2 ring-background animate-pulse" />
          )}
        </button>
      ))}
    </nav>
  );
}

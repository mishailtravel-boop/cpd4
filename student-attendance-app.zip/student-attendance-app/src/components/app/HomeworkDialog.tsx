import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import func2url from "../../../backend/func2url.json";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import Icon from "@/components/ui/icon";
import { safe, useReadyStore } from "@/hooks/use-store";
import { lessonEnd, lessonPlace, fromIso, prettyDate, type HomeworkFile, type Lesson } from "@/lib/schedule";

const API = (func2url as Record<string, string>).group;
const MAX_MB = 2.5;

function fileSize(b: number) {
  return b >= 1024 * 1024 ? `${(b / 1024 / 1024).toFixed(1)} МБ` : `${Math.max(1, Math.round(b / 1024))} КБ`;
}

function fileIcon(name: string) {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  if (["jpg", "jpeg", "png", "gif", "webp", "heic"].includes(ext)) return "Image";
  if (["xls", "xlsx", "csv"].includes(ext)) return "FileSpreadsheet";
  if (["zip", "rar", "7z"].includes(ext)) return "FileArchive";
  if (["pdf", "doc", "docx", "txt", "ppt", "pptx"].includes(ext)) return "FileText";
  return "File";
}

function readBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(",")[1] ?? "");
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

function FileList({ files, onRemove }: { files: HomeworkFile[]; onRemove?: (i: number) => void }) {
  return (
    <ul className="mt-3 flex flex-col gap-1.5">
      {files.map((f, i) => (
        <li key={f.url} className="flex items-center gap-3 rounded-[14px] bg-background px-3 py-2.5">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-[10px] bg-primary/15 text-primary">
            <Icon name={fileIcon(f.name)} size={18} />
          </span>
          <a href={f.url} target="_blank" rel="noreferrer" download={f.name} className="min-w-0 flex-1 hover:underline">
            <span className="block truncate text-sm">{f.name}</span>
            <span className="text-xs text-muted-foreground">{fileSize(f.size)}</span>
          </a>
          {onRemove ? (
            <button type="button" aria-label="Убрать файл" onClick={() => onRemove(i)} className="text-muted-foreground hover:text-destructive">
              <Icon name="X" size={16} />
            </button>
          ) : (
            <a href={f.url} target="_blank" rel="noreferrer" download={f.name} aria-label="Скачать" className="text-muted-foreground hover:text-foreground">
              <Icon name="Download" size={16} />
            </a>
          )}
        </li>
      ))}
    </ul>
  );
}

interface Props {
  lesson: Lesson | null;
  onClose: () => void;
}

export default function HomeworkDialog({ lesson, onClose }: Props) {
  const { data, call, isHead, now } = useReadyStore();
  const hw = lesson ? data.homework[lesson.subject] : undefined;
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState("");
  const [files, setFiles] = useState<HomeworkFile[]>([]);
  const [uploading, setUploading] = useState(0);
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setEditing(false);
    setText(hw?.text ?? "");
    setFiles(hw?.files ?? []);
  }, [lesson, hw]);

  const uploaded = useRef<string[]>([]);

  const discard = (keep: string[]) => {
    const urls = uploaded.current.filter((u) => !keep.includes(u));
    uploaded.current = [];
    if (urls.length) call("discard_files", { urls }).catch(() => {});
  };

  const discardUnsaved = () => discard((hw?.files ?? []).map((f) => f.url));

  const attach = async (list: FileList | null) => {
    if (!list) return;
    for (const file of Array.from(list)) {
      if (file.size > MAX_MB * 1024 * 1024) {
        toast.error(`«${file.name}» больше 2,5 МБ — сожмите или дайте ссылкой`);
        continue;
      }
      setUploading((n) => n + 1);
      try {
        const res = await fetch(API, {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-Auth-Token": localStorage.getItem("moya-gruppa-token") ?? "" },
          body: JSON.stringify({ action: "upload_file", name: file.name, type: file.type, data: await readBase64(file) }),
        });
        const json = await res.json();
        if (!res.ok) throw new Error(json.error);
        uploaded.current.push(json.file.url);
        setFiles((f) => [...f, json.file]);
      } catch (e) {
        toast.error((e as Error).message || `Не удалось загрузить «${file.name}»`);
      } finally {
        setUploading((n) => n - 1);
      }
    }
    if (input.current) input.current.value = "";
  };

  const save = async () => {
    if (!lesson) return;
    const t = new Date(now);
    const ok = await safe(
      call("set_homework", {
        subject: lesson.subject,
        text: text.trim(),
        files,
        updatedAt: `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, "0")}-${String(t.getDate()).padStart(2, "0")}`,
      }),
    );
    if (ok) {
      discard(files.map((f) => f.url));
      setEditing(false);
    }
  };

  return (
    <Dialog
      open={!!lesson}
      onOpenChange={(o) => {
        if (o) return;
        discardUnsaved();
        onClose();
      }}
    >
      <DialogContent className="w-[calc(100%-1.5rem)] max-w-lg rounded-[18px] border-0 bg-card p-6">
        {lesson && (
          <>
            <DialogHeader className="text-left">
              <span className="label-caps text-muted-foreground">
                {lesson.time}–{lessonEnd(lesson)} · {lessonPlace(lesson)}
              </span>
              <DialogTitle className="font-head text-4xl font-bold uppercase leading-[0.95]">
                {lesson.subject}
              </DialogTitle>
              <DialogDescription className="sr-only">Домашнее задание по предмету</DialogDescription>
            </DialogHeader>

            <div className="mt-2 rounded-[18px] bg-secondary p-5">
              <div className="mb-3 flex items-center justify-between">
                <span className="label-caps text-primary">Домашнее задание</span>
                {hw && !editing && (
                  <span className="text-xs text-muted-foreground">от {prettyDate(fromIso(hw.updatedAt))}</span>
                )}
              </div>
              {editing ? (
                <>
                  <div className="relative">
                    <Textarea
                      autoFocus
                      value={text}
                      onChange={(e) => setText(e.target.value)}
                      placeholder="Что задали: номера, страницы, сроки…"
                      className="min-h-[140px] rounded-[14px] border-0 bg-background pb-12 text-base"
                    />
                    <button
                      type="button"
                      onClick={() => input.current?.click()}
                      disabled={uploading > 0}
                      aria-label="Прикрепить файл"
                      title="Прикрепить файл"
                      className="absolute bottom-2 left-2 grid h-9 w-9 place-items-center rounded-full text-muted-foreground transition-colors hover:bg-secondary hover:text-primary disabled:opacity-50"
                    >
                      <Icon name={uploading ? "Loader2" : "Paperclip"} size={18} className={uploading ? "animate-spin" : ""} />
                    </button>
                    <input ref={input} type="file" multiple hidden onChange={(e) => attach(e.target.files)} />
                  </div>
                  {files.length > 0 && <FileList files={files} onRemove={(i) => setFiles((f) => f.filter((_, j) => j !== i))} />}
                </>
              ) : hw ? (
                <>
                  {hw.text && <p className="whitespace-pre-wrap text-base leading-relaxed">{hw.text}</p>}
                  {!!hw.files?.length && (
                    <div className={hw.text ? "mt-4" : ""}>
                      <span className="text-xs text-muted-foreground">Файлы · {hw.files.length}</span>
                      <FileList files={hw.files} />
                    </div>
                  )}
                </>
              ) : (
                <p className="text-muted-foreground">Пока ничего не задано. Можно выдохнуть.</p>
              )}
            </div>

            {isHead && (
              <div className="mt-2 flex flex-wrap gap-2">
                {editing ? (
                  <>
                    <button
                      onClick={save}
                      disabled={uploading > 0}
                      className="disabled:opacity-50 rounded-full bg-primary px-6 py-3 text-xs font-semibold uppercase tracking-[0.1em] text-primary-foreground"
                    >
                      Сохранить
                    </button>
                    <button
                      onClick={() => {
                        discardUnsaved();
                        setEditing(false);
                        setText(hw?.text ?? "");
                        setFiles(hw?.files ?? []);
                      }}
                      className="rounded-full bg-secondary px-6 py-3 text-xs font-semibold uppercase tracking-[0.1em]"
                    >
                      Отмена
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => setEditing(true)}
                    className="flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-xs font-semibold uppercase tracking-[0.1em] text-primary-foreground"
                  >
                    <Icon name={hw ? "Pencil" : "Plus"} size={14} />
                    {hw ? "Изменить задание" : "Добавить задание"}
                  </button>
                )}
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
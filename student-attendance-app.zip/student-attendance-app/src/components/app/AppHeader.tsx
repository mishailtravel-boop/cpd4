import { cn } from "@/lib/utils";
import { PARITY_LABEL, type Parity } from "@/lib/schedule";
import Icon from "@/components/ui/icon";

interface Props {
  parity: Parity;
  initials: string;
  onProfile: () => void;
}

export default function AppHeader({ parity, initials, onProfile }: Props) {
  return (
    <header className="flex items-center justify-between gap-3">
      <div className="min-w-0 font-head text-[1.4rem] sm:text-[1.9rem] font-bold uppercase leading-none tracking-[-0.01em]">
        Моя группа
      </div>
      <div className="flex shrink-0 items-center gap-2">
        <div
          className={cn(
            "rounded-full px-3 py-2 sm:px-[18px] text-[0.72rem] sm:text-[0.85rem] font-semibold uppercase tracking-[0.06em]",
            parity === "even" ? "bg-primary text-primary-foreground" : "bg-warning text-warning-foreground",
          )}
        >
          {PARITY_LABEL[parity]} неделя
        </div>
        <button
          type="button"
          onClick={onProfile}
          aria-label="Профиль"
          className="grid h-10 w-10 sm:h-11 sm:w-11 place-items-center rounded-full bg-secondary font-head text-sm font-semibold uppercase transition-colors hover:bg-accent"
        >
          {initials || <Icon name="User" size={18} />}
        </button>
      </div>
    </header>
  );
}
